# Vaccination Management System

A PHP 8 + MySQL application for managing child vaccination records, hospital appointments, parent requests and reporting workflows.

## Project Overview

This project includes a public website, login and registration flow, and separate role-based dashboards for:

- Admin
- Parent
- Hospital

The application supports record management, appointment booking, vaccination reporting and secure access control.

## Folder Structure

- `config/` - application configuration and environment settings
- `includes/` - shared layout, validation and authentication helpers
- `admin/` - administrator dashboard and management pages
- `parent/` - parent dashboard and profile management pages
- `hospital/` - hospital dashboard, appointments and reports
- `actions/` - server-side data handling and form processing
- `assets/` - CSS, JS and static files
- `database/` - SQL schema and import instructions
- `docs/` - Aptech project documentation and study materials
- `tests/` - manual testing checklist

## Requirements

- PHP 8.0+
- MySQL 8+ / MariaDB
- Apache or PHP built-in server
- Composer not required for this project
- Browser with JavaScript enabled

## Database Setup

1. Start Apache and MySQL in XAMPP.
2. Copy `.env.example` to `.env`.
3. Update the database values if needed.
4. Import the SQL file from `database/vaccination_management.sql`.
5. Confirm the database is accessible before running the app.

## Environment Configuration

Create a `.env` file with values like:

```env
DB_HOST=127.0.0.1
DB_PORT=3306
DB_NAME=vaccination_management
DB_USER=root
DB_PASS=
APP_URL=http://localhost/VAXCARE
APP_ENV=local
```

If the local environment uses a different MySQL username or password, update the values accordingly.

## Run the Project

### Option 1: PHP built-in server

```bash
cd c:/xampp/htdocs/VAXCARE
php -S localhost:8000
```

Then open:

```text
http://localhost:8000/
```

### Option 2: XAMPP Apache server

- Place the project in `c:/xampp/htdocs/VAXCARE`
- Start Apache and MySQL
- Open `http://localhost/VAXCARE/`

## Seeded Demo Accounts

These accounts are created by the database import script:

- Admin: `admin@vaxcare.local` / `Admin@123`
- Parent: `parent@vaxcare.local` / `Parent@123`
- Hospital: `hospital@vaxcare.local` / `Hospital@123`

Change them via the profile or directly in the database after login if needed.

## Login Roles

- Admin: management dashboard, vaccines, hospitals, reports
- Parent: children, schedules, appointment requests and history
- Hospital: assigned appointments, inventory and vaccination outcomes

## Troubleshooting

- If MySQL connection fails, check the values in `.env`.
- If the database does not exist, import `database/vaccination_management.sql` again.
- If pages show blank sections, confirm Apache and PHP are running.
- If a role cannot access pages, confirm the user record and assigned role are correct.

## Manual Testing

Use the checklist in `tests/manual_test_checklist.md` to validate login, registration, approval workflows and dashboard pages.

## Notes

This project is designed for learning and academic evaluation. The system uses secure password hashes, prepared statements and role-based access controls, but it is intended for local educational use and not production deployment.
