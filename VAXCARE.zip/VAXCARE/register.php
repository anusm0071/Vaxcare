<?php
require_once __DIR__ . '/includes/header.php';
$pageTitle = 'Register';
?>
<section class="py-5">
    <div class="container">
        <div class="card auth-card shadow-sm border-0 p-4">
            <h2 class="text-center mb-4">Create an Account</h2>
            <?php displayFlash(); ?>
            <form method="POST" action="actions/register_action.php">
                <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars(generateCsrfToken(), ENT_QUOTES, 'UTF-8'); ?>">
                <div class="mb-3">
                    <label class="form-label">Register as</label>
                    <select class="form-select" name="role" id="roleSelect">
                        <option value="parent">Parent</option>
                        <option value="hospital">Hospital</option>
                    </select>
                </div>
                <div class="mb-3">
                    <label class="form-label">Full Name / Hospital Name</label>
                    <input type="text" class="form-control" name="name" required>
                </div>
                <div class="mb-3">
                    <label class="form-label">Email</label>
                    <input type="email" class="form-control" name="email" required>
                </div>
                <div class="mb-3">
                    <label class="form-label">Phone</label>
                    <input type="text" class="form-control" name="phone" required>
                </div>
                <div class="mb-3" id="addressField">
                    <label class="form-label">Address</label>
                    <input type="text" class="form-control" name="address">
                </div>
                <div class="mb-3">
                    <label class="form-label">City</label>
                    <input type="text" class="form-control" name="city">
                </div>
                <div class="mb-3" id="hospitalField" style="display:none;">
                    <label class="form-label">Hospital Name</label>
                    <input type="text" class="form-control" name="hospital_name">
                </div>
                <div class="mb-3">
                    <label class="form-label">Password</label>
                    <input type="password" class="form-control" name="password" required>
                </div>
                <button class="btn btn-primary w-100" type="submit">Register</button>
            </form>
            <p class="text-center mt-3 mb-0">Already have an account? <a href="login.php">Login</a></p>
        </div>
    </div>
</section>
<script>
const roleSelect = document.getElementById('roleSelect');
const hospitalField = document.getElementById('hospitalField');
const addressField = document.getElementById('addressField');

function toggleRoleFields() {
    const isHospital = roleSelect.value === 'hospital';
    hospitalField.style.display = isHospital ? 'block' : 'none';
    addressField.style.display = isHospital ? 'block' : 'block';
}
roleSelect.addEventListener('change', toggleRoleFields);
toggleRoleFields();
</script>
<?php include __DIR__ . '/includes/footer.php'; ?>
