<?php
require_once __DIR__ . '/../includes/auth.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    redirect('../register.php');
}

if (!verifyCsrfToken($_POST['csrf_token'] ?? '')) {
    flash('error', 'Security token expired. Please try again.');
    redirect('../register.php');
}

$role = $_POST['role'] ?? 'parent';
if (!in_array($role, ['parent', 'hospital'], true)) {
    flash('error', 'Invalid registration role.');
    redirect('../register.php');
}

$name = sanitizeString($_POST['name'] ?? '');
$email = sanitizeString($_POST['email'] ?? '');
$password = $_POST['password'] ?? '';
$phone = sanitizeString($_POST['phone'] ?? '');

if ($name === '' || !validateEmail($email) || $password === '' || strlen($password) < 6 || !validatePhone($phone)) {
    flash('error', 'Please complete all fields with valid values.');
    redirect('../register.php');
}

try {
    $pdo = getDb();
    $pdo->beginTransaction();

    $stmt = $pdo->prepare('SELECT id FROM users WHERE email = :email LIMIT 1');
    $stmt->execute([':email' => $email]);
    if ($stmt->fetch()) {
        throw new RuntimeException('This email is already registered.');
    }

    $passwordHash = password_hash($password, PASSWORD_BCRYPT);
    $userStmt = $pdo->prepare('INSERT INTO users (name, email, password_hash, phone, role, status, created_at, updated_at) VALUES (:name, :email, :password_hash, :phone, :role, "active", NOW(), NOW())');
    $userStmt->execute([
        ':name' => $name,
        ':email' => $email,
        ':password_hash' => $passwordHash,
        ':phone' => $phone,
        ':role' => $role,
    ]);
    $userId = (int) $pdo->lastInsertId();

    if ($role === 'parent') {
        $address = sanitizeString($_POST['address'] ?? '');
        $city = sanitizeString($_POST['city'] ?? '');
        $stmt = $pdo->prepare('INSERT INTO parents (user_id, address, city, phone, created_at, updated_at) VALUES (:user_id, :address, :city, :phone, NOW(), NOW())');
        $stmt->execute([
            ':user_id' => $userId,
            ':address' => $address,
            ':city' => $city,
            ':phone' => $phone,
        ]);
    } else {
        $hospitalName = sanitizeString($_POST['hospital_name'] ?? '');
        $address = sanitizeString($_POST['address'] ?? '');
        $city = sanitizeString($_POST['city'] ?? '');
        $stmt = $pdo->prepare('INSERT INTO hospitals (user_id, hospital_name, address, city, phone, email, status, created_at, updated_at) VALUES (:user_id, :hospital_name, :address, :city, :phone, :email, "active", NOW(), NOW())');
        $stmt->execute([
            ':user_id' => $userId,
            ':hospital_name' => $hospitalName,
            ':address' => $address,
            ':city' => $city,
            ':phone' => $phone,
            ':email' => $email,
        ]);
    }

    $pdo->commit();
    flash('success', 'Registration completed successfully. You can now log in.');
    redirect('../login.php');
} catch (Throwable $e) {
    if (isset($pdo) && $pdo->inTransaction()) {
        $pdo->rollBack();
    }
    error_log($e->getMessage());
    flash('error', $e->getMessage() ?: 'Registration failed.');
    redirect('../register.php');
}
