<?php
require_once __DIR__ . '/../includes/auth.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    redirect('login.php');
}

if (!verifyCsrfToken($_POST['csrf_token'] ?? '')) {
    flash('error', 'Security token expired. Please try again.');
    redirect('../login.php');
}

$email = sanitizeString($_POST['email'] ?? '');
$password = $_POST['password'] ?? '';

if (!validateEmail($email) || $password === '') {
    flash('error', 'Please enter a valid email and password.');
    redirect('../login.php');
}

try {
    $pdo = getDb();
    $stmt = $pdo->prepare('SELECT * FROM users WHERE email = :email AND status = "active" LIMIT 1');
    $stmt->execute([':email' => $email]);
    $user = $stmt->fetch();

    if (!$user || !password_verify($password, $user['password_hash'])) {
        flash('error', 'Incorrect email or password.');
        redirect('../login.php');
    }

    session_regenerate_id(true);
    $_SESSION['user'] = [
        'id' => (int) $user['id'],
        'role' => $user['role'],
        'name' => $user['name'],
        'email' => $user['email'],
    ];

    addAuditLog((int) $user['id'], 'login', 'users', (int) $user['id'], 'User logged in.');

    $redirectPath = '../index.php';
    if ($user['role'] === 'admin') {
        $redirectPath = '../admin/dashboard.php';
    } elseif ($user['role'] === 'parent') {
        $redirectPath = '../parent/dashboard.php';
    } elseif ($user['role'] === 'hospital') {
        $redirectPath = '../hospital/dashboard.php';
    }

    flash('success', 'Login successful.');
    redirect($redirectPath);
} catch (Throwable $e) {
    error_log($e->getMessage());
    flash('error', 'Login failed due to a system error.');
    redirect('../login.php');
}
