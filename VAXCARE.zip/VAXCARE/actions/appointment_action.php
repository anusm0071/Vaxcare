<?php
require_once __DIR__ . '/../includes/auth.php';
requireRole(['parent']);

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    redirect('../parent/book_appointment.php');
}

if (!verifyCsrfToken($_POST['csrf_token'] ?? '')) {
    flash('error', 'Security token expired. Please try again.');
    redirect('../parent/book_appointment.php');
}

$action = sanitizeString($_POST['action'] ?? 'create');

if ($action === 'cancel') {
    $appointmentId = (int)($_POST['appointment_id'] ?? 0);
    if ($appointmentId <= 0) {
        flash('error', 'Appointment not found.');
        redirect('../parent/appointments.php');
    }

    try {
        $pdo = getDb();
        $parent = fetchParentByUserId((int) currentUser()['id']);
        $stmt = $pdo->prepare('UPDATE appointments SET status = "Cancelled", updated_at = NOW() WHERE id = :id AND parent_id = :parent_id AND status IN ("Pending", "Approved")');
        $stmt->execute([':id' => $appointmentId, ':parent_id' => (int)$parent['id']]);
        if ($stmt->rowCount() > 0) {
            flash('success', 'Appointment cancelled successfully.');
        } else {
            flash('error', 'This appointment cannot be cancelled.');
        }
        redirect('../parent/appointments.php');
    } catch (Throwable $e) {
        error_log($e->getMessage());
        flash('error', 'Unable to cancel appointment.');
        redirect('../parent/appointments.php');
    }
}

$childId = (int)($_POST['child_id'] ?? 0);
$hospitalId = (int)($_POST['hospital_id'] ?? 0);
$vaccineId = (int)($_POST['vaccine_id'] ?? 0);
$appointmentDate = sanitizeString($_POST['appointment_date'] ?? '');
$slot = sanitizeString($_POST['slot_time'] ?? '09:00');

if ($childId <= 0 || $hospitalId <= 0 || $vaccineId <= 0 || !validateDate($appointmentDate) || $slot === '') {
    flash('error', 'Please select valid booking details.');
    redirect('../parent/book_appointment.php');
}

try {
    $pdo = getDb();
    $parent = fetchParentByUserId((int) currentUser()['id']);
    if (!$parent) {
        throw new RuntimeException('Parent account not found.');
    }

    $stmt = $pdo->prepare('SELECT * FROM children WHERE id = :id AND parent_id = :parent_id LIMIT 1');
    $stmt->execute([':id' => $childId, ':parent_id' => (int)$parent['id']]);
    if (!$stmt->fetch()) {
        throw new RuntimeException('Child not associated with this parent.');
    }

    $stmt = $pdo->prepare('INSERT INTO appointments (child_id, parent_id, hospital_id, vaccine_id, appointment_date, slot_time, status, notes, created_at, updated_at) VALUES (:child_id, :parent_id, :hospital_id, :vaccine_id, :appointment_date, :slot_time, "Pending", "Parent request submitted.", NOW(), NOW())');
    $stmt->execute([
        ':child_id' => $childId,
        ':parent_id' => (int)$parent['id'],
        ':hospital_id' => $hospitalId,
        ':vaccine_id' => $vaccineId,
        ':appointment_date' => $appointmentDate,
        ':slot_time' => $slot,
    ]);

    addNotification((int) currentUser()['id'], 'Appointment requested', 'Your vaccination booking has been submitted and is awaiting review.', 'info');
    flash('success', 'Appointment request submitted successfully.');
    redirect('../parent/appointments.php');
} catch (Throwable $e) {
    error_log($e->getMessage());
    flash('error', 'Unable to submit appointment request.');
    redirect('../parent/book_appointment.php');
}
