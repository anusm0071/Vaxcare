<?php
require_once __DIR__ . '/../includes/auth.php';
requireRole(['parent']);

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    redirect('../parent/children.php');
}

if (!verifyCsrfToken($_POST['csrf_token'] ?? '')) {
    flash('error', 'Security token expired. Please try again.');
    redirect('../parent/children.php');
}

$parent = fetchParentByUserId((int) currentUser()['id']);
if (!$parent) {
    flash('error', 'Parent record not found.');
    redirect('../parent/children.php');
}

$id = (int)($_POST['id'] ?? 0);
$name = sanitizeString($_POST['name'] ?? '');
$dateOfBirth = sanitizeString($_POST['date_of_birth'] ?? '');
$gender = sanitizeString($_POST['gender'] ?? '');
$allergies = sanitizeString($_POST['allergies'] ?? '');
$notes = sanitizeString($_POST['medical_notes'] ?? '');

if ($name === '' || !validateDate($dateOfBirth) || !in_array($gender, ['Male', 'Female', 'Other'], true)) {
    flash('error', 'Please provide valid child details.');
    redirect('../parent/child_form.php' . ($id > 0 ? '?id=' . $id : ''));
}

try {
    $pdo = getDb();
    if ($id > 0) {
        $stmt = $pdo->prepare('UPDATE children SET name = :name, date_of_birth = :date_of_birth, gender = :gender, allergies = :allergies, medical_notes = :notes, updated_at = NOW() WHERE id = :id AND parent_id = :parent_id');
        $stmt->execute([':name' => $name, ':date_of_birth' => $dateOfBirth, ':gender' => $gender, ':allergies' => $allergies, ':notes' => $notes, ':id' => $id, ':parent_id' => (int)$parent['id']]);
        flash('success', 'Child record updated.');
    } else {
        $stmt = $pdo->prepare('INSERT INTO children (parent_id, name, date_of_birth, gender, allergies, medical_notes, status, created_at, updated_at) VALUES (:parent_id, :name, :date_of_birth, :gender, :allergies, :medical_notes, "active", NOW(), NOW())');
        $stmt->execute([':parent_id' => (int)$parent['id'], ':name' => $name, ':date_of_birth' => $dateOfBirth, ':gender' => $gender, ':allergies' => $allergies, ':medical_notes' => $notes]);
        flash('success', 'Child added successfully.');
    }
    redirect('../parent/children.php');
} catch (Throwable $e) {
    error_log($e->getMessage());
    flash('error', 'Unable to save child record.');
    redirect('../parent/children.php');
}
