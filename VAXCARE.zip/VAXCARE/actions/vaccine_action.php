<?php

require_once __DIR__ . '/../includes/auth.php';
requireRole(['admin']);

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    redirect('../admin/vaccines.php');
}

if (!verifyCsrfToken($_POST['csrf_token'] ?? '')) {
    flash('error', 'Security token expired. Please try again.');
    redirect('../admin/vaccines.php');
}

$action = sanitizeString($_POST['action'] ?? 'save');
$id = (int)($_POST['id'] ?? 0);
$name = sanitizeString($_POST['name'] ?? '');
$description = sanitizeString($_POST['description'] ?? '');
$status = sanitizeString($_POST['status'] ?? 'active');

if (!in_array($status, ['active', 'inactive'], true)) {
    $status = 'active';
}

try {
    $pdo = getDb();

    if ($action === 'save') {
        if ($name === '') {
            throw new RuntimeException('Vaccine name is required.');
        }

        if ($id > 0) {
            $stmt = $pdo->prepare('UPDATE vaccines SET name = :name, description = :description, status = :status, updated_at = NOW() WHERE id = :id');
            $stmt->execute([
                ':name' => $name,
                ':description' => $description,
                ':status' => $status,
                ':id' => $id,
            ]);
            addAuditLog((int) currentUser()['id'], 'update', 'vaccines', $id, 'Updated vaccine: ' . $name);
            flash('success', 'Vaccine updated successfully.');
        } else {
            $stmt = $pdo->prepare('INSERT INTO vaccines (name, description, status, created_at, updated_at) VALUES (:name, :description, :status, NOW(), NOW())');
            $stmt->execute([
                ':name' => $name,
                ':description' => $description,
                ':status' => $status,
            ]);
            $newId = (int) $pdo->lastInsertId();
            addAuditLog((int) currentUser()['id'], 'create', 'vaccines', $newId, 'Added vaccine: ' . $name);
            flash('success', 'Vaccine added successfully.');
        }
    } elseif ($action === 'delete' || $action === 'deactivate') {
        if ($id <= 0) {
            throw new RuntimeException('Invalid vaccine ID.');
        }

        // Soft delete: deactivate instead of removing, preserving historical records
        $stmt = $pdo->prepare('UPDATE vaccines SET status = "inactive", updated_at = NOW() WHERE id = :id');
        $stmt->execute([':id' => $id]);
        addAuditLog((int) currentUser()['id'], 'deactivate', 'vaccines', $id, 'Deactivated vaccine ID: ' . $id);
        flash('success', 'Vaccine deactivated. Historical vaccination records are preserved.');
    }

    redirect('../admin/vaccines.php');
} catch (Throwable $e) {
    error_log($e->getMessage());
    flash('error', $e->getMessage() ?: 'Unable to process vaccine request.');
    redirect('../admin/vaccines.php');
}