<?php
require_once __DIR__ . '/../includes/auth.php';
requireRole(['parent', 'admin', 'hospital']);

if ($_SERVER['REQUEST_METHOD'] !== 'POST' || ($_POST['action'] ?? '') !== 'mark_read') {
    redirect('../index.php');
}

if (!verifyCsrfToken($_POST['csrf_token'] ?? '')) {
    flash('error', 'Security token expired.');
    redirect('../index.php');
}

$notificationId = (int)($_POST['notification_id'] ?? 0);
$userId = (int) currentUser()['id'];
try {
    $pdo = getDb();
    $stmt = $pdo->prepare('UPDATE notifications SET is_read = 1 WHERE id = :id AND user_id = :user_id');
    $stmt->execute([':id' => $notificationId, ':user_id' => $userId]);
    flash('success', 'Notification marked as read.');
} catch (Throwable $e) {
    error_log($e->getMessage());
    flash('error', 'Unable to update notification.');
}

$redirect = '../index.php';
if (currentUser()['role'] === 'parent') { $redirect = '../parent/notifications.php'; }
if (currentUser()['role'] === 'hospital') { $redirect = '../hospital/dashboard.php'; }
if (currentUser()['role'] === 'admin') { $redirect = '../admin/notifications.php'; }
redirect($redirect);
