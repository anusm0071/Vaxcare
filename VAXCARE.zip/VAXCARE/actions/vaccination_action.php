<?php
require_once __DIR__ . '/../includes/auth.php';
requireRole(['hospital']);

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    redirect('../hospital/appointments.php');
}

if (!verifyCsrfToken($_POST['csrf_token'] ?? '')) {
    flash('error', 'Security token expired. Please try again.');
    redirect('../hospital/appointments.php');
}

$appointmentId = (int)($_POST['appointment_id'] ?? 0);
$status = sanitizeString($_POST['status'] ?? '');
$notes = sanitizeString($_POST['notes'] ?? '');
$vaccineId = (int)($_POST['vaccine_id'] ?? 0);

if ($appointmentId <= 0) {
    flash('error', 'Appointment not found.');
    redirect('../hospital/appointments.php');
}

try {
    $pdo = getDb();
    $hospital = fetchHospitalByUserId((int) currentUser()['id']);
    $stmt = $pdo->prepare('SELECT * FROM appointments WHERE id = :id AND hospital_id = :hospital_id LIMIT 1');
    $stmt->execute([':id' => $appointmentId, ':hospital_id' => (int)$hospital['id']]);
    $appointment = $stmt->fetch();

    if (!$appointment) {
        throw new RuntimeException('This appointment is not assigned to your hospital.');
    }

    if ($status === 'Completed') {
        if ($vaccineId <= 0) {
            throw new RuntimeException('Vaccine selection is required for completion.');
        }
        $stmt = $pdo->prepare('INSERT INTO vaccination_records (appointment_id, child_id, hospital_id, vaccine_id, dose_number, vaccination_date, notes, status, created_at) VALUES (:appointment_id, :child_id, :hospital_id, :vaccine_id, 1, CURDATE(), :notes, "Completed", NOW())');
        $stmt->execute([
            ':appointment_id' => $appointmentId,
            ':child_id' => (int)$appointment['child_id'],
            ':hospital_id' => (int)$hospital['id'],
            ':vaccine_id' => $vaccineId,
            ':notes' => $notes,
        ]);
        $pdo->prepare('UPDATE appointments SET status = "Completed", notes = :notes, completed_at = NOW(), updated_at = NOW() WHERE id = :id')->execute([':notes' => $notes, ':id' => $appointmentId]);
        flash('success', 'Vaccination completed and recorded successfully.');
    } else {
        $pdo->prepare('UPDATE appointments SET status = :status, notes = :notes, updated_at = NOW() WHERE id = :id')->execute([':status' => $status, ':notes' => $notes, ':id' => $appointmentId]);
        flash('success', 'Appointment status updated successfully.');
    }

    redirect('../hospital/appointments.php');
} catch (Throwable $e) {
    error_log($e->getMessage());
    flash('error', $e->getMessage() ?: 'Unable to update appointment status.');
    redirect('../hospital/appointments.php');
}
