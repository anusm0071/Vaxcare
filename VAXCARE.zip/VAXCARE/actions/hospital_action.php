<?php
require_once __DIR__ . '/../includes/auth.php';
requireRole(['hospital']);

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    redirect('../hospital/profile.php');
}

if (!verifyCsrfToken($_POST['csrf_token'] ?? '')) {
    flash('error', 'Security token expired. Please try again.');
    redirect('../hospital/profile.php');
}

$hospital = fetchHospitalByUserId((int) currentUser()['id']);
if (!$hospital) {
    flash('error', 'Hospital profile not found.');
    redirect('../hospital/profile.php');
}

$name = sanitizeString($_POST['hospital_name'] ?? '');
$address = sanitizeString($_POST['address'] ?? '');
$city = sanitizeString($_POST['city'] ?? '');
$phone = sanitizeString($_POST['phone'] ?? '');
$email = sanitizeString($_POST['email'] ?? '');

if ($name === '' || $city === '' || !validatePhone($phone) || !validateEmail($email)) {
    flash('error', 'Please provide valid hospital details.');
    redirect('../hospital/profile.php');
}

try {
    $pdo = getDb();
    $stmt = $pdo->prepare('UPDATE hospitals SET hospital_name = :name, address = :address, city = :city, phone = :phone, email = :email, updated_at = NOW() WHERE id = :id');
    $stmt->execute([
        ':name' => $name,
        ':address' => $address,
        ':city' => $city,
        ':phone' => $phone,
        ':email' => $email,
        ':id' => (int)$hospital['id'],
    ]);
    flash('success', 'Hospital profile updated successfully.');
    redirect('../hospital/profile.php');
} catch (Throwable $e) {
    error_log($e->getMessage());
    flash('error', 'Unable to update hospital profile.');
    redirect('../hospital/profile.php');
}
