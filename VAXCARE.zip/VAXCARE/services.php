<?php
require_once __DIR__ . '/includes/header.php';
$pageTitle = 'Services';
?>
<section class="py-5">
    <div class="container">
        <div class="text-center mb-5">
            <h1 class="section-title">Our Services</h1>
        </div>
        <div class="row g-4">
            <div class="col-md-6 col-lg-4">
                <div class="feature-card h-100 p-4">
                    <h5>Child Record Management</h5>
                    <p class="text-secondary mb-0">Store and track child profiles, schedules and vaccination history securely.</p>
                </div>
            </div>
            <div class="col-md-6 col-lg-4">
                <div class="feature-card h-100 p-4">
                    <h5>Appointment Booking</h5>
                    <p class="text-secondary mb-0">Parents can request appointments with hospitals and monitors key status updates.</p>
                </div>
            </div>
            <div class="col-md-6 col-lg-4">
                <div class="feature-card h-100 p-4">
                    <h5>Hospital Coordination</h5>
                    <p class="text-secondary mb-0">Hospitals manage schedules, vaccine inventory and vaccination completion updates.</p>
                </div>
            </div>
        </div>
    </div>
</section>
<?php include __DIR__ . '/includes/footer.php'; ?>
