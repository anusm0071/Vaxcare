# Manual Test Checklist

## Test Case ID: TC-01
Module: Public Website
Scenario: Landing page loads
Preconditions: Project is running
Steps: Open the homepage
Expected Result: Home page displays hero, feature cards and navigation
Actual Result: [To be completed]
Pass/Fail: [To be completed]

## Test Case ID: TC-02
Module: Authentication
Scenario: Admin login succeeds
Preconditions: Database imported and admin user exists
Steps: Submit admin credentials
Expected Result: Admin dashboard loads
Actual Result: [To be completed]
Pass/Fail: [To be completed]

## Test Case ID: TC-03
Module: Parent Workflow
Scenario: Parent adds child profile
Preconditions: Parent account is logged in
Steps: Add child details from the child form
Expected Result: Child record saves and appears in the list
Actual Result: [To be completed]
Pass/Fail: [To be completed]

## Test Case ID: TC-04
Module: Hospital Workflow
Scenario: Hospital updates appointment status
Preconditions: Hospital is logged in and appointment exists
Steps: Open appointment details and set status
Expected Result: Status updates in the database
Actual Result: [To be completed]
Pass/Fail: [To be completed]

## Test Case ID: TC-05
Module: Reports
Scenario: Admin filters report by date and status
Preconditions: Appointment records exist
Steps: Fill report filters and submit
Expected Result: Matching appointments appear in the table
Actual Result: [To be completed]
Pass/Fail: [To be completed]
