<?php
require_once __DIR__ . '/includes/header.php';
$pageTitle = 'Home';
?>
<section class="hero-section">
    <div class="container">
        <div class="row align-items-center gy-4">
            <div class="col-lg-6">
                <span class="badge bg-primary-soft text-primary px-3 py-2 rounded-pill mb-3">Trusted vaccination record management</span>
                <h1 class="display-5 fw-bold">Healthy Children, Brighter Future</h1>
                <p class="lead text-secondary mt-3">
                    VAXCARE helps parents, hospitals and administrators track vaccination schedules, appointments and child health records in one secure platform.
                </p>
                <div class="d-flex gap-3 flex-wrap mt-4">
                    <a href="register.php" class="btn btn-primary btn-lg">Get Started</a>
                    <a href="vaccination-guide.php" class="btn btn-outline-primary btn-lg">Explore Vaccination Guide</a>
                </div>
            </div>
            <div class="col-lg-6">
                <div class="card p-4 border-0 shadow-sm">
                    <img src="https://images.unsplash.com/photo-1576091160550-2173dba999ef?auto=format&fit=crop&w=900&q=80" class="img-fluid rounded-4" alt="Doctor and child" />
                </div>
            </div>
        </div>
    </div>
</section>

<section class="py-5">
    <div class="container">
        <div class="text-center mb-5">
            <h2 class="section-title">Why parents rely on VAXCARE</h2>
        </div>
        <div class="row g-4">
            <div class="col-md-6 col-lg-3">
                <div class="feature-card h-100 p-4">
                    <div class="mb-3 text-primary fs-2"><i class="bi bi-person-add"></i></div>
                    <h5>Child Registration</h5>
                    <p class="text-secondary mb-0">Create secure child profiles and keep vaccination history organized.</p>
                </div>
            </div>
            <div class="col-md-6 col-lg-3">
                <div class="feature-card h-100 p-4">
                    <div class="mb-3 text-primary fs-2"><i class="bi bi-calendar2-check"></i></div>
                    <h5>Book Appointment</h5>
                    <p class="text-secondary mb-0">Request vaccination visits with the right hospital and preferred slot.</p>
                </div>
            </div>
            <div class="col-md-6 col-lg-3">
                <div class="feature-card h-100 p-4">
                    <div class="mb-3 text-primary fs-2"><i class="bi bi-clipboard2-pulse"></i></div>
                    <h5>Track Vaccination</h5>
                    <p class="text-secondary mb-0">Monitor upcoming, overdue and completed immunization records.</p>
                </div>
            </div>
            <div class="col-md-6 col-lg-3">
                <div class="feature-card h-100 p-4">
                    <div class="mb-3 text-primary fs-2"><i class="bi bi-hospital"></i></div>
                    <h5>Find Hospitals</h5>
                    <p class="text-secondary mb-0">Search for nearby hospitals and available vaccination services.</p>
                </div>
            </div>
        </div>
    </div>
</section>

<section class="py-5 bg-white">
    <div class="container">
        <div class="text-center mb-5">
            <h2 class="section-title">How It Works</h2>
        </div>
        <div class="row g-4 text-center">
            <div class="col-md-4">
                <div class="info-card h-100 p-4">
                    <div class="display-6 text-primary mb-3">1</div>
                    <h5>Register</h5>
                    <p class="text-secondary mb-0">Create a parent or hospital account to join the platform.</p>
                </div>
            </div>
            <div class="col-md-4">
                <div class="info-card h-100 p-4">
                    <div class="display-6 text-primary mb-3">2</div>
                    <h5>Schedule</h5>
                    <p class="text-secondary mb-0">Add child records and select the recommended vaccines.</p>
                </div>
            </div>
            <div class="col-md-4">
                <div class="info-card h-100 p-4">
                    <div class="display-6 text-primary mb-3">3</div>
                    <h5>Track</h5>
                    <p class="text-secondary mb-0">Review updates, bookings and vaccination completion history.</p>
                </div>
            </div>
        </div>
    </div>
</section>

<section class="py-5">
    <div class="container">
        <div class="row align-items-center gy-4">
            <div class="col-lg-6">
                <h2 class="section-title">Vaccination keeps every child protected</h2>
                <p class="text-secondary">
                    Timely vaccination helps reduce disease risk and supports healthy development. VAXCARE keeps schedules clear and accessible for families and healthcare staff.
                </p>
                <ul class="list-unstyled">
                    <li class="mb-2"><i class="bi bi-check-circle-fill text-primary me-2"></i>Track due and overdue vaccines</li>
                    <li class="mb-2"><i class="bi bi-check-circle-fill text-primary me-2"></i>Manage appointment approvals and records</li>
                    <li class="mb-2"><i class="bi bi-check-circle-fill text-primary me-2"></i>Access hospital inventory and vaccination reports</li>
                </ul>
            </div>
            <div class="col-lg-6">
                <div class="card p-4 border-0">
                    <img src="https://images.unsplash.com/photo-1584515933487-779824d29309?auto=format&fit=crop&w=900&q=80" class="img-fluid rounded-4" alt="Vaccination support" />
                </div>
            </div>
        </div>
    </div>
</section>

<section class="py-5 bg-white">
    <div class="container">
        <div class="text-center mb-5">
            <h2 class="section-title">Frequently Asked Questions</h2>
        </div>
        <div class="accordion" id="faqAccordion">
            <div class="accordion-item">
                <h2 class="accordion-header">
                    <button class="accordion-button" type="button" data-bs-toggle="collapse" data-bs-target="#faq1">How do I book a vaccination appointment?</button>
                </h2>
                <div id="faq1" class="accordion-collapse collapse show" data-bs-parent="#faqAccordion">
                    <div class="accordion-body">Register as a parent, add your child, then use the booking form to choose a hospital and vaccination date.</div>
                </div>
            </div>
            <div class="accordion-item">
                <h2 class="accordion-header">
                    <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#faq2">Can the hospital update vaccination details?</button>
                </h2>
                <div id="faq2" class="accordion-collapse collapse" data-bs-parent="#faqAccordion">
                    <div class="accordion-body">Yes. Hospitals can review approved appointments, update outcomes and record vaccination completion.</div>
                </div>
            </div>
            <div class="accordion-item">
                <h2 class="accordion-header">
                    <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#faq3">Is the data secure?</button>
                </h2>
                <div id="faq3" class="accordion-collapse collapse" data-bs-parent="#faqAccordion">
                    <div class="accordion-body">The system uses secured password hashing, PDO statements and role-based access checks.</div>
                </div>
            </div>
        </div>
    </div>
</section>

<?php include __DIR__ . '/includes/footer.php'; ?>
