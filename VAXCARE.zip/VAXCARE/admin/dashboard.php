<?php
require_once __DIR__ . '/../includes/auth.php';
requireRole(['admin']);
$pageTitle = 'Admin Dashboard';
$pdo = getDb();
$counts = getDashboardCounts();
$chartRows = $pdo->query("SELECT DATE_FORMAT(appointment_date, '%b %d') AS label, COUNT(*) AS total FROM appointments WHERE appointment_date >= DATE_SUB(CURDATE(), INTERVAL 6 DAY) GROUP BY appointment_date ORDER BY appointment_date ")->fetchAll();
$labels = json_encode(array_column($chartRows, 'label'));
$values = json_encode(array_column($chartRows, 'total'));
$recent = $pdo->query("SELECT a.id, c.name AS child_name, h.hospital_name, a.status, a.appointment_date FROM appointments a LEFT JOIN children c ON c.id = a.child_id LEFT JOIN hospitals h ON h.id = a.hospital_id ORDER BY a.created_at DESC LIMIT 5")->fetchAll();
include __DIR__ . '/../includes/header.php';
?>
<div class="dashboard-shell">
    <?php include __DIR__ . '/../includes/admin_sidebar.php'; ?>
    <div class="content-panel">
        <div class="d-flex justify-content-between align-items-center mb-4">
            <div>
                <h2 class="mb-1">Dashboard Overview</h2>
                <p class="text-secondary mb-0">Live vaccination and appointment data from the database.</p>
            </div>
        </div>
        <?php displayFlash(); ?>
        <div class="row g-4 mb-4">
            <?php
            $stats = [
                ['icon' => 'bi-people', 'label' => 'Registered Children', 'value' => $counts['children']],
                ['icon' => 'bi-person-lines-fill', 'label' => 'Registered Parents', 'value' => $counts['parents']],
                ['icon' => 'bi-hospital', 'label' => 'Hospitals', 'value' => $counts['hospitals']],
                ['icon' => 'bi-shield-plus', 'label' => 'Vaccine Types', 'value' => $counts['vaccines']],
            ];
            foreach ($stats as $stat): ?>
            <div class="col-md-6 col-xl-3">
                <div class="stat-card h-100">
                    <div class="d-flex align-items-center justify-content-between">
                        <div>
                            <div class="text-secondary small"><?php echo htmlspecialchars($stat['label']); ?></div>
                            <div class="fs-3 fw-bold"><?php echo $stat['value']; ?></div>
                        </div>
                        <div class="stat-icon"><i class="bi <?php echo htmlspecialchars($stat['icon']); ?>"></i></div>
                    </div>
                </div>
            </div>
            <?php endforeach; ?>
        </div>

        <div class="row g-4 mb-4">
            <div class="col-lg-8">
                <div class="card h-100 p-3 chart-card">
                    <h5 class="mb-3">Recent vaccination activity</h5>
                    <canvas id="vaccinationChart" data-labels='<?php echo $labels; ?>' data-values='<?php echo $values; ?>' style="height: 260px;"></canvas>
                </div>
            </div>
            <div class="col-lg-4">
                <div class="card h-100 p-3">
                    <h5 class="mb-3">System status</h5>
                    <ul class="list-group list-group-flush">
                        <li class="list-group-item d-flex justify-content-between"><span>Pending requests</span><strong><?php echo $counts['pending_requests']; ?></strong></li>
                        <li class="list-group-item d-flex justify-content-between"><span>Upcoming appointments</span><strong><?php echo $counts['upcoming']; ?></strong></li>
                    </ul>
                </div>
            </div>
        </div>

        <div class="card p-3">
            <div class="d-flex justify-content-between align-items-center mb-3">
                <h5 class="mb-0">Recent bookings</h5>
            </div>
            <div class="table-responsive">
                <table class="table table-striped align-middle mb-0">
                    <thead>
                        <tr>
                            <th>Child</th>
                            <th>Hospital</th>
                            <th>Date</th>
                            <th>Status</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (!$recent): ?>
                            <tr><td colspan="4" class="text-center text-secondary">No records found.</td></tr>
                        <?php else: foreach ($recent as $row): ?>
                            <tr>
                                <td><?php echo htmlspecialchars($row['child_name'] ?? 'Unknown'); ?></td>
                                <td><?php echo htmlspecialchars($row['hospital_name'] ?? 'Unknown'); ?></td>
                                <td><?php echo formatDate($row['appointment_date']); ?></td>
                                <td><span class="status-badge status-<?php echo htmlspecialchars($row['status']); ?>"><?php echo htmlspecialchars($row['status']); ?></span></td>
                            </tr>
                        <?php endforeach; endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
<?php include __DIR__ . '/../includes/footer.php'; ?>
