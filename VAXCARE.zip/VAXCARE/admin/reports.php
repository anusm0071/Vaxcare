<?php
require_once __DIR__ . '/../includes/auth.php';
requireRole(['admin']);
$pageTitle = 'Reports';
$pdo = getDb();
$fromDate = sanitizeString($_GET['from_date'] ?? '');
$toDate = sanitizeString($_GET['to_date'] ?? '');
$status = sanitizeString($_GET['status'] ?? '');
$query = 'SELECT a.*, c.name AS child_name, h.hospital_name, v.name AS vaccine_name FROM appointments a LEFT JOIN children c ON c.id = a.child_id LEFT JOIN hospitals h ON h.id = a.hospital_id LEFT JOIN vaccines v ON v.id = a.vaccine_id WHERE 1 = 1';
$params = [];
if ($fromDate !== '') { $query .= ' AND a.appointment_date >= :from_date'; $params[':from_date'] = $fromDate; }
if ($toDate !== '') { $query .= ' AND a.appointment_date <= :to_date'; $params[':to_date'] = $toDate; }
if ($status !== '') { $query .= ' AND a.status = :status'; $params[':status'] = $status; }
$stmt = $pdo->prepare($query . ' ORDER BY a.appointment_date DESC');
$stmt->execute($params);
$rows = $stmt->fetchAll();
include __DIR__ . '/../includes/header.php';
?>
<div class="dashboard-shell">
    <?php include __DIR__ . '/../includes/admin_sidebar.php'; ?>
    <div class="content-panel">
        <h2 class="mb-3">Reports</h2>
        <form method="GET" class="card p-3 mb-4">
            <div class="row g-3 align-items-end">
                <div class="col-md-3"><label class="form-label">From</label><input type="date" class="form-control" name="from_date" value="<?php echo htmlspecialchars($fromDate); ?>"></div>
                <div class="col-md-3"><label class="form-label">To</label><input type="date" class="form-control" name="to_date" value="<?php echo htmlspecialchars($toDate); ?>"></div>
                <div class="col-md-3"><label class="form-label">Status</label><select class="form-select" name="status"><option value="">All</option><option value="Pending" <?php echo $status === 'Pending' ? 'selected' : ''; ?>>Pending</option><option value="Approved" <?php echo $status === 'Approved' ? 'selected' : ''; ?>>Approved</option><option value="Completed" <?php echo $status === 'Completed' ? 'selected' : ''; ?>>Completed</option></select></div>
                <div class="col-md-3"><button class="btn btn-primary w-100" type="submit">Filter</button></div>
            </div>
        </form>
        <div class="card p-3">
            <div class="table-responsive">
                <table class="table mb-0">
                    <thead><tr><th>Child</th><th>Hospital</th><th>Vaccine</th><th>Date</th><th>Status</th></tr></thead>
                    <tbody>
                        <?php if (!$rows): ?>
                            <tr><td colspan="5" class="text-center text-secondary">No report data available for the selected filters.</td></tr>
                        <?php else: foreach ($rows as $row): ?>
                            <tr>
                                <td><?php echo htmlspecialchars($row['child_name']); ?></td>
                                <td><?php echo htmlspecialchars($row['hospital_name']); ?></td>
                                <td><?php echo htmlspecialchars($row['vaccine_name']); ?></td>
                                <td><?php echo formatDate($row['appointment_date']); ?></td>
                                <td><span class="status-badge status-<?php echo htmlspecialchars($row['status']); ?>"><?php echo htmlspecialchars($row['status']); ?></span></td>
                            </tr>
                        <?php endforeach; endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
<?php include __DIR__ . '/../includes/footer.php'; ?>
