<?php
require_once __DIR__ . '/../includes/auth.php';
requireRole(['admin']);
$pageTitle = 'Vaccine Management';
$pdo = getDb();
$vaccines = $pdo->query('SELECT * FROM vaccines ORDER BY created_at DESC')->fetchAll();
include __DIR__ . '/../includes/header.php';
?>
<div class="dashboard-shell">
    <?php include __DIR__ . '/../includes/admin_sidebar.php'; ?>
    <div class="content-panel">
        <h2 class="mb-3">Vaccine Management</h2>
        <?php displayFlash(); ?>
        <div class="row g-4">
            <div class="col-lg-4">
                <div class="card p-4">
                    <h5>Add Vaccine</h5>
                    <form method="POST" action="../actions/vaccine_action.php">
                        <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars(generateCsrfToken(), ENT_QUOTES, 'UTF-8'); ?>">
                        <input type="hidden" name="action" value="save">
                        <div class="mb-3">
                            <label class="form-label">Vaccine Name</label>
                            <input type="text" class="form-control" name="name" required>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Description</label>
                            <textarea class="form-control" name="description" rows="4"></textarea>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Status</label>
                            <select class="form-select" name="status">
                                <option value="active">Active</option>
                                <option value="inactive">Inactive</option>
                            </select>
                        </div>
                        <button class="btn btn-primary" type="submit">Save Vaccine</button>
                    </form>
                </div>
            </div>
            <div class="col-lg-8">
                <div class="card p-3">
                    <div class="table-responsive">
                        <table class="table table-hover mb-0">
                            <thead>
                                <tr>
                                    <th>Name</th>
                                    <th>Description</th>
                                    <th>Status</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php if (!$vaccines): ?>
                                    <tr><td colspan="4" class="text-center text-secondary">No vaccines available.</td></tr>
                                <?php else: foreach ($vaccines as $v): ?>
                                    <tr>
                                        <td><?php echo htmlspecialchars($v['name']); ?></td>
                                        <td><?php echo htmlspecialchars($v['description'] ?? '-'); ?></td>
                                        <td><span class="status-badge status-<?php echo htmlspecialchars($v['status']); ?>"><?php echo htmlspecialchars($v['status']); ?></span></td>
                                        <td>
                                            <?php if ($v['status'] === 'active'): ?>
                                                <form method="POST" action="../actions/vaccine_action.php" class="d-inline" onsubmit="return confirm('Deactivate this vaccine? Historical records will be preserved.');">
                                                    <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars(generateCsrfToken(), ENT_QUOTES, 'UTF-8'); ?>">
                                                    <input type="hidden" name="action" value="deactivate">
                                                    <input type="hidden" name="id" value="<?php echo (int) $v['id']; ?>">
                                                    <button class="btn btn-sm btn-outline-danger" type="submit">Deactivate</button>
                                                </form>
                                            <?php else: ?>
                                                <form method="POST" action="../actions/vaccine_action.php" class="d-inline">
                                                    <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars(generateCsrfToken(), ENT_QUOTES, 'UTF-8'); ?>">
                                                    <input type="hidden" name="action" value="save">
                                                    <input type="hidden" name="id" value="<?php echo (int) $v['id']; ?>">
                                                    <input type="hidden" name="name" value="<?php echo htmlspecialchars($v['name'], ENT_QUOTES, 'UTF-8'); ?>">
                                                    <input type="hidden" name="description" value="<?php echo htmlspecialchars($v['description'] ?? '', ENT_QUOTES, 'UTF-8'); ?>">
                                                    <input type="hidden" name="status" value="active">
                                                    <button class="btn btn-sm btn-outline-success" type="submit">Reactivate</button>
                                                </form>
                                            <?php endif; ?>
                                        </td>
                                    </tr>
                                <?php endforeach; endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php include __DIR__ . '/../includes/footer.php'; ?>
