<?php
require_once __DIR__ . '/../includes/auth.php';
requireRole(['admin']);
$pageTitle = 'Children';
$pdo = getDb();
$children = $pdo->query("SELECT c.*, p.user_id as parent_user_id, u.name AS parent_name FROM children c LEFT JOIN parents p ON p.id = c.parent_id LEFT JOIN users u ON u.id = p.user_id ORDER BY c.created_at DESC")->fetchAll();
include __DIR__ . '/../includes/header.php';
?>
<div class="dashboard-shell">
    <?php include __DIR__ . '/../includes/admin_sidebar.php'; ?>
    <div class="content-panel">
        <h2 class="mb-3">Child Records</h2>
        <?php displayFlash(); ?>
        <div class="card p-3">
            <div class="table-responsive">
                <table class="table table-hover mb-0">
                    <thead>
                        <tr>
                            <th>Name</th>
                            <th>Parent</th>
                            <th>Date of Birth</th>
                            <th>Gender</th>
                            <th>Status</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (!$children): ?>
                            <tr><td colspan="5" class="text-center text-secondary">No children found.</td></tr>
                        <?php else: foreach ($children as $child): ?>
                            <tr>
                                <td><?php echo htmlspecialchars($child['name']); ?></td>
                                <td><?php echo htmlspecialchars($child['parent_name'] ?? 'Unknown'); ?></td>
                                <td><?php echo formatDate($child['date_of_birth']); ?></td>
                                <td><?php echo htmlspecialchars($child['gender']); ?></td>
                                <td><span class="status-badge status-<?php echo htmlspecialchars($child['status']); ?>"><?php echo htmlspecialchars($child['status']); ?></span></td>
                            </tr>
                        <?php endforeach; endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
<?php include __DIR__ . '/../includes/footer.php'; ?>
