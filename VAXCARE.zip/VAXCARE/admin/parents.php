<?php
require_once __DIR__ . '/../includes/auth.php';
requireRole(['admin']);
$pageTitle = 'Parents';
$pdo = getDb();
$parents = $pdo->query('SELECT p.*, u.name, u.email, u.phone FROM parents p LEFT JOIN users u ON u.id = p.user_id ORDER BY p.created_at DESC')->fetchAll();
include __DIR__ . '/../includes/header.php';
?>
<div class="dashboard-shell">
    <?php include __DIR__ . '/../includes/admin_sidebar.php'; ?>
    <div class="content-panel">
        <h2 class="mb-3">Registered Parents</h2>
        <div class="card p-3">
            <div class="table-responsive">
                <table class="table table-hover mb-0">
                    <thead>
                        <tr><th>Name</th><th>Email</th><th>Phone</th><th>City</th></tr>
                    </thead>
                    <tbody>
                        <?php if (!$parents): ?>
                            <tr><td colspan="4" class="text-center text-secondary">No parents found.</td></tr>
                        <?php else: foreach ($parents as $parent): ?>
                            <tr>
                                <td><?php echo htmlspecialchars($parent['name']); ?></td>
                                <td><?php echo htmlspecialchars($parent['email']); ?></td>
                                <td><?php echo htmlspecialchars($parent['phone']); ?></td>
                                <td><?php echo htmlspecialchars($parent['city'] ?? '-'); ?></td>
                            </tr>
                        <?php endforeach; endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
<?php include __DIR__ . '/../includes/footer.php'; ?>
