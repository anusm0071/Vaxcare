<?php
require_once __DIR__ . '/../includes/auth.php';
requireRole(['admin']);
$pageTitle = 'Appointment Details';
$pdo = getDb();

$appointmentId = (int)($_GET['id'] ?? 0);
if ($appointmentId <= 0) {
    flash('error', 'Invalid appointment ID.');
    redirect('appointments.php');
}

$stmt = $pdo->prepare('SELECT a.*, c.name AS child_name, c.date_of_birth, p.id AS parent_id, u.name AS parent_name, u.email AS parent_email, h.hospital_name, h.city AS hospital_city, v.name AS vaccine_name FROM appointments a LEFT JOIN children c ON c.id = a.child_id LEFT JOIN parents p ON p.id = a.parent_id LEFT JOIN users u ON u.id = p.user_id LEFT JOIN hospitals h ON h.id = a.hospital_id LEFT JOIN vaccines v ON v.id = a.vaccine_id WHERE a.id = :id LIMIT 1');
$stmt->execute([':id' => $appointmentId]);
$appointment = $stmt->fetch();

if (!$appointment) {
    flash('error', 'Appointment not found.');
    redirect('appointments.php');
}

include __DIR__ . '/../includes/header.php';
?>
<div class="dashboard-shell">
    <?php include __DIR__ . '/../includes/admin_sidebar.php'; ?>
    <div class="content-panel">
        <div class="d-flex justify-content-between align-items-center mb-3">
            <div>
                <h2 class="mb-0">Appointment Details</h2>
                <p class="text-secondary mb-0">Booking and vaccination record information</p>
            </div>
            <a href="appointments.php" class="btn btn-outline-secondary"><i class="bi bi-arrow-left"></i> Back to Appointments</a>
        </div>
        <?php displayFlash(); ?>

        <div class="card p-4">
            <div class="row g-3">
                <div class="col-md-6"><strong class="text-secondary d-small">Appointment ID:</strong> #<?php echo (int) $appointment['id']; ?></div>
                <div class="col-md-6"><strong class="text-secondary d-small">Child:</strong> <?php echo htmlspecialchars($appointment['child_name']); ?></div>
                <div class="col-md-6"><strong class="text-secondary d-small">Parent:</strong> <?php echo htmlspecialchars($appointment['parent_name'] ?? 'Not available'); ?></div>
                <div class="col-md-6"><strong class="text-secondary d-small">Parent Email:</strong> <?php echo htmlspecialchars($appointment['parent_email'] ?? 'Not available'); ?></div>
                <div class="col-md-6"><strong class="text-secondary d-small">Hospital:</strong> <?php echo htmlspecialchars($appointment['hospital_name']); ?></div>
                <div class="col-md-6"><strong class="text-secondary d-small">Hospital City:</strong> <?php echo htmlspecialchars($appointment['hospital_city']); ?></div>
                <div class="col-md-6"><strong class="text-secondary d-small">Vaccine:</strong> <?php echo htmlspecialchars($appointment['vaccine_name']); ?></div>
                <div class="col-md-6"><strong class="text-secondary d-small">Date:</strong> <?php echo formatDate($appointment['appointment_date']); ?></div>
                <div class="col-md-6"><strong class="text-secondary d-small">Time:</strong> <?php echo htmlspecialchars($appointment['slot_time']); ?></div>
                <div class="col-md-6"><strong class="text-secondary d-small">Status:</strong> <span class="status-badge status-<?php echo htmlspecialchars($appointment['status']); ?>"><?php echo htmlspecialchars($appointment['status']); ?></span></div>
                <?php if ($appointment['rejection_reason']): ?>
                <div class="col-md-6"><strong class="text-secondary d-small">Rejection Reason:</strong> <?php echo htmlspecialchars($appointment['rejection_reason']); ?></div>
                <?php endif; ?>
                <div class="col-md-6"><strong class="text-secondary d-small">Notes:</strong> <?php echo htmlspecialchars($appointment['notes'] ?? 'None'); ?></div>
                <div class="col-md-6"><strong class="text-secondary d-small">Requested:</strong> <?php echo formatDate($appointment['requested_at']); ?></div>
                <?php if ($appointment['approved_at']): ?>
                <div class="col-md-6"><strong class="text-secondary d-small">Approved:</strong> <?php echo formatDate($appointment['approved_at']); ?></div>
                <?php endif; ?>
                <?php if ($appointment['completed_at']): ?>
                <div class="col-md-6"><strong class="text-secondary d-small">Completed:</strong> <?php echo formatDate($appointment['completed_at']); ?></div>
                <?php endif; ?>
            </div>
        </div>

        <?php if ($appointment['status'] === 'Pending'): ?>
        <div class="card p-4 mt-4">
            <h5 class="mb-3">Manage Request</h5>
            <form method="POST" action="appointments.php" class="row g-3">
                <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars(generateCsrfToken(), ENT_QUOTES, 'UTF-8'); ?>">
                <input type="hidden" name="id" value="<?php echo (int) $appointment['id']; ?>">
                <div class="col-md-4">
                    <label class="form-label">Rejection Reason</label>
                    <input type="text" class="form-control" name="reason" placeholder="Reason for rejection">
                </div>
                <div class="col-md-4 d-flex align-items-end">
                    <button class="btn btn-success me-2" name="action" value="approve" type="submit">Approve</button>
                    <button class="btn btn-danger" name="action" value="reject" type="submit" onclick="return confirm('Reject this appointment request?')">Reject</button>
                </div>
            </form>
        </div>
        <?php endif; ?>
    </div>
</div>
<?php include __DIR__ . '/../includes/footer.php'; ?>