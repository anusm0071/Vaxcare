<?php
require_once __DIR__ . '/../includes/auth.php';
requireRole(['admin']);
$pageTitle = 'Child Details';
$pdo = getDb();

$childId = (int)($_GET['id'] ?? 0);
if ($childId <= 0) {
    flash('error', 'Invalid child ID.');
    redirect('children.php');
}

$stmt = $pdo->prepare('SELECT c.*, p.id AS parent_id, u.name AS parent_name, u.email AS parent_email, u.phone AS parent_phone FROM children c LEFT JOIN parents p ON p.id = c.parent_id LEFT JOIN users u ON u.id = p.user_id WHERE c.id = :id LIMIT 1');
$stmt->execute([':id' => $childId]);
$child = $stmt->fetch();

if (!$child) {
    flash('error', 'Child record not found.');
    redirect('children.php');
}

$records = $pdo->prepare('SELECT vr.*, v.name AS vaccine_name, h.hospital_name FROM vaccination_records vr LEFT JOIN vaccines v ON v.id = vr.vaccine_id LEFT JOIN hospitals h ON h.id = vr.hospital_id WHERE vr.child_id = :child_id ORDER BY vr.vaccination_date DESC');
$records->execute([':child_id' => $childId]);
$historyRows = $records->fetchAll();

$appointments = $pdo->prepare('SELECT a.*, h.hospital_name, v.name AS vaccine_name FROM appointments a LEFT JOIN hospitals h ON h.id = a.hospital_id LEFT JOIN vaccines v ON v.id = a.vaccine_id WHERE a.child_id = :child_id ORDER BY a.appointment_date DESC');
$appointments->execute([':child_id' => $childId]);
$appointmentRows = $appointments->fetchAll();

include __DIR__ . '/../includes/header.php';
?>
<div class="dashboard-shell">
    <?php include __DIR__ . '/../includes/admin_sidebar.php'; ?>
    <div class="content-panel">
        <div class="d-flex justify-content-between align-items-center mb-3">
            <div>
                <h2 class="mb-0">Child Details</h2>
                <p class="text-secondary mb-0">Vaccination history and appointment records</p>
            </div>
            <a href="children.php" class="btn btn-outline-secondary"><i class="bi bi-arrow-left"></i> Back to Children</a>
        </div>
        <?php displayFlash(); ?>

        <div class="row g-4 mb-4">
            <div class="col-md-6">
                <div class="card p-4">
                    <h5 class="mb-3">Child Information</h5>
                    <div class="mb-2"><strong class="text-secondary d-small">Name:</strong> <?php echo htmlspecialchars($child['name']); ?></div>
                    <div class="mb-2"><strong class="text-secondary d-small">Date of Birth:</strong> <?php echo formatDate($child['date_of_birth']); ?></div>
                    <div class="mb-2"><strong class="text-secondary d-small">Gender:</strong> <?php echo htmlspecialchars($child['gender']); ?></div>
                    <div class="mb-2"><strong class="text-secondary d-small">Allergies:</strong> <?php echo htmlspecialchars($child['allergies'] ?? 'None recorded'); ?></div>
                    <div class="mb-2"><strong class="text-secondary d-small">Status:</strong> <span class="status-badge status-<?php echo htmlspecialchars($child['status']); ?>"><?php echo htmlspecialchars($child['status']); ?></span></div>
                    <div class="mb-2"><strong class="text-secondary d-small">Registered:</strong> <?php echo formatDate($child['created_at']); ?></div>
                </div>
            </div>
            <div class="col-md-6">
                <div class="card p-4">
                    <h5 class="mb-3">Parent Information</h5>
                    <div class="mb-2"><strong class="text-secondary d-small">Name:</strong> <?php echo htmlspecialchars($child['parent_name'] ?? 'Not available'); ?></div>
                    <div class="mb-2"><strong class="text-secondary d-small">Email:</strong> <?php echo htmlspecialchars($child['parent_email'] ?? 'Not available'); ?></div>
                    <div class="mb-2"><strong class="text-secondary d-small">Phone:</strong> <?php echo htmlspecialchars($child['parent_phone'] ?? 'Not available'); ?></div>
                </div>
            </div>
        </div>
        <?php if (!empty($child['medical_notes'])): ?>
        <div class="card p-4 mb-4" id="medical-notes">
            <h5 class="mb-3">Medical Notes</h5>
            <p><?php echo nl2br(htmlspecialchars($child['medical_notes'])); ?></p>
        </div>
        <?php endif; ?>

        <div class="card p-3 mb-4">
            <h5 class="mb-3">Vaccination History</h5>
            <div class="table-responsive">
                <table class="table table-hover mb-0">
                    <thead>
                        <tr><th>Vaccine</th><th>Hospital</th><th>Dose</th><th>Date</th><th>Status</th><th>Notes</th></tr>
                    </thead>
                    <tbody>
                        <?php if (!$historyRows): ?>
                            <tr><td colspan="6" class="text-center text-secondary">No vaccination records found.</td></tr>
                        <?php else: foreach ($historyRows as $record): ?>
                            <tr>
                                <td><?php echo htmlspecialchars($record['vaccine_name'] ?? 'Unknown'); ?></td>
                                <td><?php echo htmlspecialchars($record['hospital_name'] ?? 'Unknown'); ?></td>
                                <td><?php echo (int) $record['dose_number']; ?></td>
                                <td><?php echo formatDate($record['vaccination_date']); ?></td>
                                <td><span class="status-badge status-<?php echo htmlspecialchars($record['status']); ?>"><?php echo htmlspecialchars($record['status']); ?></span></td>
                                <td><?php echo htmlspecialchars($record['notes'] ?? '-'); ?></td>
                            </tr>
                        <?php endforeach; endif; ?>
                    </tbody>
                </table>
            </div>
        </div>

        <div class="card p-3">
            <h5 class="mb-3">Appointment Records</h5>
            <div class="table-responsive">
                <table class="table table-hover mb-0">
                    <thead>
                        <tr><th>Vaccine</th><th>Hospital</th><th>Date</th><th>Slot</th><th>Status</th></tr>
                    </thead>
                    <tbody>
                        <?php if (!$appointmentRows): ?>
                            <tr><td colspan="5" class="text-center text-secondary">No appointments found.</td></tr>
                        <?php else: foreach ($appointmentRows as $appt): ?>
                            <tr>
                                <td><?php echo htmlspecialchars($appt['vaccine_name'] ?? 'Unknown'); ?></td>
                                <td><?php echo htmlspecialchars($appt['hospital_name'] ?? 'Unknown'); ?></td>
                                <td><?php echo formatDate($appt['appointment_date']); ?></td>
                                <td><?php echo htmlspecialchars($appt['slot_time']); ?></td>
                                <td><span class="status-badge status-<?php echo htmlspecialchars($appt['status']); ?>"><?php echo htmlspecialchars($appt['status']); ?></span></td>
                            </tr>
                        <?php endforeach; endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
<?php include __DIR__ . '/../includes/footer.php'; ?>