<?php
require_once __DIR__ . '/../includes/auth.php';
requireRole(['admin']);
$pageTitle = 'Admin Notifications';
$pdo = getDb();
$notifications = $pdo->query('SELECT * FROM notifications ORDER BY created_at DESC LIMIT 20')->fetchAll();
include __DIR__ . '/../includes/header.php';
?>
<div class="dashboard-shell">
    <?php include __DIR__ . '/../includes/admin_sidebar.php'; ?>
    <div class="content-panel">
        <h2 class="mb-3">Notifications</h2>
        <div class="card p-3">
            <?php if (!$notifications): ?>
                <div class="text-secondary text-center py-4">No notifications found.</div>
            <?php else: foreach ($notifications as $n): ?>
                <div class="border rounded p-3 mb-3">
                    <div class="d-flex justify-content-between">
                        <strong><?php echo htmlspecialchars($n['title']); ?></strong>
                        <span class="small text-secondary"><?php echo formatDate($n['created_at']); ?></span>
                    </div>
                    <p class="mb-0 text-secondary"><?php echo htmlspecialchars($n['message']); ?></p>
                </div>
            <?php endforeach; endif; ?>
        </div>
    </div>
</div>
<?php include __DIR__ . '/../includes/footer.php'; ?>
