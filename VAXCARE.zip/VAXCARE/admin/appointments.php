<?php
require_once __DIR__ . '/../includes/auth.php';
requireRole(['admin']);
$pageTitle = 'Appointments';
$pdo = getDb();
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'approve') {
    $id = (int)($_POST['id'] ?? 0);
    if ($id > 0) {
        $stmt = $pdo->prepare('UPDATE appointments SET status = "Approved", approved_at = NOW(), updated_at = NOW() WHERE id = :id');
        $stmt->execute([':id' => $id]);
        flash('success', 'Appointment approved.');
    }
    redirect('appointments.php');
}
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'reject') {
    $id = (int)($_POST['id'] ?? 0);
    $reason = sanitizeString($_POST['reason'] ?? 'Rejected by admin');
    if ($id > 0) {
        $stmt = $pdo->prepare('UPDATE appointments SET status = "Rejected", rejection_reason = :reason, updated_at = NOW() WHERE id = :id');
        $stmt->execute([':id' => $id, ':reason' => $reason]);
        flash('success', 'Appointment rejected.');
    }
    redirect('appointments.php');
}
$appointments = $pdo->query("SELECT a.*, c.name AS child_name, h.hospital_name, v.name AS vaccine_name FROM appointments a LEFT JOIN children c ON c.id = a.child_id LEFT JOIN hospitals h ON h.id = a.hospital_id LEFT JOIN vaccines v ON v.id = a.vaccine_id ORDER BY a.created_at DESC")->fetchAll();
include __DIR__ . '/../includes/header.php';
?>
<div class="dashboard-shell">
    <?php include __DIR__ . '/../includes/admin_sidebar.php'; ?>
    <div class="content-panel">
        <h2 class="mb-3">Appointment Requests</h2>
        <?php displayFlash(); ?>
        <div class="card p-3">
            <div class="table-responsive">
                <table class="table table-hover mb-0">
                    <thead>
                        <tr>
                            <th>Child</th>
                            <th>Hospital</th>
                            <th>Vaccine</th>
                            <th>Date</th>
                            <th>Status</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (!$appointments): ?>
                            <tr><td colspan="6" class="text-center text-secondary">No appointments found.</td></tr>
                        <?php else: foreach ($appointments as $appointment): ?>
                            <tr>
                                <td><?php echo htmlspecialchars($appointment['child_name']); ?></td>
                                <td><?php echo htmlspecialchars($appointment['hospital_name'] ?? '-'); ?></td>
                                <td><?php echo htmlspecialchars($appointment['vaccine_name'] ?? '-'); ?></td>
                                <td><?php echo formatDate($appointment['appointment_date']); ?></td>
                                <td><span class="status-badge status-<?php echo htmlspecialchars($appointment['status']); ?>"><?php echo htmlspecialchars($appointment['status']); ?></span></td>
                                <td>
                                    <?php if ($appointment['status'] === 'Pending'): ?>
                                        <form method="POST" class="d-inline">
                                            <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars(generateCsrfToken(), ENT_QUOTES, 'UTF-8'); ?>">
                                            <input type="hidden" name="action" value="approve">
                                            <input type="hidden" name="id" value="<?php echo (int)$appointment['id']; ?>">
                                            <button class="btn btn-sm btn-success me-2" type="submit">Approve</button>
                                        </form>
                                        <form method="POST" class="d-inline">
                                            <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars(generateCsrfToken(), ENT_QUOTES, 'UTF-8'); ?>">
                                            <input type="hidden" name="action" value="reject">
                                            <input type="hidden" name="id" value="<?php echo (int)$appointment['id']; ?>">
                                            <input type="hidden" name="reason" value="Rejected by admin">
                                            <button class="btn btn-sm btn-danger" type="submit">Reject</button>
                                        </form>
                                    <?php endif; ?>
                                </td>
                            </tr>
                        <?php endforeach; endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
<?php include __DIR__ . '/../includes/footer.php'; ?>
