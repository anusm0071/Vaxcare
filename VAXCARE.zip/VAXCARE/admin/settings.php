<?php
require_once __DIR__ . '/../includes/auth.php';
requireRole(['admin']);
$pageTitle = 'Settings';
include __DIR__ . '/../includes/header.php';
?>
<div class="dashboard-shell">
    <?php include __DIR__ . '/../includes/admin_sidebar.php'; ?>
    <div class="content-panel">
        <h2 class="mb-3">System Settings</h2>
        <div class="card p-4">
            <p class="text-secondary">This project is configured to use environment variables for database connection details and role-based access control.</p>
            <ul>
                <li>Application name: <?php echo APP_NAME; ?></li>
                <li>Environment: <?php echo APP_ENV; ?></li>
                <li>Database host: <?php echo env('DB_HOST', '127.0.0.1'); ?></li>
                <li>Database name: <?php echo env('DB_NAME', 'vaccination_management'); ?></li>
            </ul>
        </div>
    </div>
</div>
<?php include __DIR__ . '/../includes/footer.php'; ?>
