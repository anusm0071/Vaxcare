<?php
require_once __DIR__ . '/../includes/auth.php';
requireRole(['admin']);
$pageTitle = 'Hospital Management';
$pdo = getDb();
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'save') {
    if (!verifyCsrfToken($_POST['csrf_token'] ?? '')) {
        flash('error', 'Security token expired. Please try again.');
        redirect('hospitals.php');
    }

    $name = sanitizeString($_POST['hospital_name'] ?? '');
    $address = sanitizeString($_POST['address'] ?? '');
    $city = sanitizeString($_POST['city'] ?? '');
    $phone = sanitizeString($_POST['phone'] ?? '');
    $email = sanitizeString($_POST['email'] ?? '');

    if ($name !== '' && $city !== '' && validatePhone($phone) && validateEmail($email)) {
        // Admin-created hospitals start without a linked user account (user_id = NULL).
        // A hospital user can later register and claim the profile.
        $stmt = $pdo->prepare('INSERT INTO hospitals (user_id, hospital_name, address, city, phone, email, status, created_at, updated_at) VALUES (NULL, :name, :address, :city, :phone, :email, "active", NOW(), NOW())');
        $stmt->execute([
            ':name' => $name,
            ':address' => $address,
            ':city' => $city,
            ':phone' => $phone,
            ':email' => $email,
        ]);
        addAuditLog((int) currentUser()['id'], 'create', 'hospitals', (int) $pdo->lastInsertId(), 'Added hospital: ' . $name);
        flash('success', 'Hospital added successfully.');
    } else {
        flash('error', 'Please submit valid hospital details.');
    }
    redirect('hospitals.php');
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && in_array($_POST['action'] ?? '', ['deactivate_hospital', 'activate_hospital'], true)) {
    if (!verifyCsrfToken($_POST['csrf_token'] ?? '')) {
        flash('error', 'Security token expired. Please try again.');
        redirect('hospitals.php');
    }

    $id = (int)($_POST['id'] ?? 0);
    $newStatus = $_POST['action'] === 'activate_hospital' ? 'active' : 'inactive';

    if ($id > 0) {
        $stmt = $pdo->prepare('UPDATE hospitals SET status = :status, updated_at = NOW() WHERE id = :id');
        $stmt->execute([':status' => $newStatus, ':id' => $id]);
        addAuditLog((int) currentUser()['id'], $newStatus === 'active' ? 'activate' : 'deactivate', 'hospitals', $id, 'Hospital status changed to ' . $newStatus);
        flash('success', 'Hospital status updated to ' . ucfirst($newStatus) . '.');
    } else {
        flash('error', 'Invalid hospital ID.');
    }
    redirect('hospitals.php');
}
$hospitals = $pdo->query('SELECT * FROM hospitals ORDER BY created_at DESC')->fetchAll();
include __DIR__ . '/../includes/header.php';
?>
<div class="dashboard-shell">
    <?php include __DIR__ . '/../includes/admin_sidebar.php'; ?>
    <div class="content-panel">
        <h2 class="mb-3">Hospitals</h2>
        <?php displayFlash(); ?>
        <div class="row g-4">
            <div class="col-lg-4">
                <div class="card p-4">
                    <h5>Add Hospital</h5>
                    <form method="POST" action="hospitals.php">
                        <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars(generateCsrfToken(), ENT_QUOTES, 'UTF-8'); ?>">
                        <input type="hidden" name="action" value="save">
                        <div class="mb-3">
                            <label class="form-label">Hospital Name</label>
                            <input type="text" class="form-control" name="hospital_name" required>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Address</label>
                            <input type="text" class="form-control" name="address">
                        </div>
                        <div class="mb-3">
                            <label class="form-label">City</label>
                            <input type="text" class="form-control" name="city" required>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Phone</label>
                            <input type="text" class="form-control" name="phone" required>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Email</label>
                            <input type="email" class="form-control" name="email" required>
                        </div>
                        <button class="btn btn-primary w-100" type="submit">Add Hospital</button>
                    </form>
                </div>
            </div>
            <div class="col-lg-8">
                <div class="card p-3">
                    <div class="table-responsive">
                        <table class="table table-hover mb-0">
                            <thead>
                                <tr>
                                    <th>Name</th>
                                    <th>Address</th>
                                    <th>City</th>
                                    <th>Phone</th>
                                    <th>Email</th>
                                    <th>Status</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php if (!$hospitals): ?>
                                    <tr><td colspan="7" class="text-center text-secondary">No hospitals found.</td></tr>
                                <?php else: foreach ($hospitals as $hospital): ?>
                                    <tr>
                                        <td><?php echo htmlspecialchars($hospital['hospital_name']); ?></td>
                                        <td><?php echo htmlspecialchars($hospital['address'] ?? '-'); ?></td>
                                        <td><?php echo htmlspecialchars($hospital['city'] ?? '-'); ?></td>
                                        <td><?php echo htmlspecialchars($hospital['phone'] ?? '-'); ?></td>
                                        <td><?php echo htmlspecialchars($hospital['email'] ?? '-'); ?></td>
                                        <td><span class="status-badge status-<?php echo htmlspecialchars($hospital['status']); ?>"><?php echo htmlspecialchars($hospital['status']); ?></span></td>
                                        <td>
                                            <?php if ($hospital['status'] === 'active'): ?>
                                                <form method="POST" class="d-inline" onsubmit="return confirm('Deactivate this hospital? Appointments and history are preserved.');">
                                                    <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars(generateCsrfToken(), ENT_QUOTES, 'UTF-8'); ?>">
                                                    <input type="hidden" name="action" value="deactivate_hospital">
                                                    <input type="hidden" name="id" value="<?php echo (int) $hospital['id']; ?>">
                                                    <button class="btn btn-sm btn-outline-danger" type="submit">Deactivate</button>
                                                </form>
                                            <?php else: ?>
                                                <form method="POST" class="d-inline" onsubmit="return confirm('Reactivate this hospital?');">
                                                    <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars(generateCsrfToken(), ENT_QUOTES, 'UTF-8'); ?>">
                                                    <input type="hidden" name="action" value="activate_hospital">
                                                    <input type="hidden" name="id" value="<?php echo (int) $hospital['id']; ?>">
                                                    <button class="btn btn-sm btn-outline-success" type="submit">Reactivate</button>
                                                </form>
                                            <?php endif; ?>
                                        </td>
                                    </tr>
                                <?php endforeach; endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php include __DIR__ . '/../includes/footer.php'; ?>
