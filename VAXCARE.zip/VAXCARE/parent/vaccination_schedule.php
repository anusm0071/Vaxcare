<?php
require_once __DIR__ . '/../includes/auth.php';
requireRole(['parent']);
$pageTitle = 'Vaccination Schedule';
$pdo = getDb();
$parent = fetchParentByUserId((int)currentUser()['id']);
$children = $pdo->prepare('SELECT * FROM children WHERE parent_id = :parent_id AND status = "active" ORDER BY date_of_birth DESC');
$children->execute([':parent_id' => (int)$parent['id']]);
$childrenRows = $children->fetchAll();
$schedules = $pdo->query('SELECT s.*, v.name AS vaccine_name FROM vaccination_schedules s LEFT JOIN vaccines v ON v.id = s.vaccine_id WHERE v.status = "active" ORDER BY s.recommended_age_months ASC')->fetchAll();
include __DIR__ . '/../includes/header.php';
?>
<div class="dashboard-shell">
    <?php include __DIR__ . '/../includes/parent_sidebar.php'; ?>
    <div class="content-panel">
        <h2 class="mb-3">Recommended Vaccination Schedule</h2>
        <div class="card p-3">
            <div class="table-responsive">
                <table class="table table-hover mb-0">
                    <thead>
                        <tr>
                            <th>Vaccine</th>
                            <th>Dose</th>
                            <th>Recommended Age</th>
                            <th>Notes</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (!$schedules): ?>
                            <tr><td colspan="4" class="text-center text-secondary">Schedule data not available.</td></tr>
                        <?php else: foreach ($schedules as $schedule): ?>
                            <tr>
                                <td><?php echo htmlspecialchars($schedule['vaccine_name']); ?></td>
                                <td><?php echo (int)$schedule['dose_number']; ?></td>
                                <td><?php echo (int)$schedule['recommended_age_months']; ?> months</td>
                                <td><?php echo htmlspecialchars($schedule['description'] ?? ''); ?></td>
                            </tr>
                        <?php endforeach; endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
<?php include __DIR__ . '/../includes/footer.php'; ?>
