<?php
require_once __DIR__ . '/../includes/auth.php';
requireRole(['parent']);
$pageTitle = 'My Appointments';
$pdo = getDb();
$parent = fetchParentByUserId((int)currentUser()['id']);
$appointments = $pdo->prepare('SELECT a.*, c.name AS child_name, h.hospital_name, v.name AS vaccine_name FROM appointments a LEFT JOIN children c ON c.id = a.child_id LEFT JOIN hospitals h ON h.id = a.hospital_id LEFT JOIN vaccines v ON v.id = a.vaccine_id WHERE a.parent_id = :parent_id ORDER BY a.appointment_date DESC');
$appointments->execute([':parent_id' => (int)$parent['id']]);
$rows = $appointments->fetchAll();
include __DIR__ . '/../includes/header.php';
?>
<div class="dashboard-shell">
    <?php include __DIR__ . '/../includes/parent_sidebar.php'; ?>
    <div class="content-panel">
        <h2 class="mb-3">My Appointments</h2>
        <?php displayFlash(); ?>
        <div class="card p-3">
            <div class="table-responsive">
                <table class="table mb-0">
                    <thead>
                        <tr>
                            <th>Child</th>
                            <th>Hospital</th>
                            <th>Vaccine</th>
                            <th>Date</th>
                            <th>Status</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (!$rows): ?>
                            <tr><td colspan="6" class="text-center text-secondary">No appointments yet.</td></tr>
                        <?php else: foreach ($rows as $row): ?>
                            <tr>
                                <td><?php echo htmlspecialchars($row['child_name']); ?></td>
                                <td><?php echo htmlspecialchars($row['hospital_name'] ?? 'Unknown'); ?></td>
                                <td><?php echo htmlspecialchars($row['vaccine_name'] ?? 'Unknown'); ?></td>
                                <td><?php echo formatDate($row['appointment_date']); ?></td>
                                <td><span class="status-badge status-<?php echo htmlspecialchars($row['status']); ?>"><?php echo htmlspecialchars($row['status']); ?></span></td>
                                <td>
                                    <?php if (in_array($row['status'], ['Pending', 'Approved'], true)): ?>
                                        <form method="POST" action="../actions/appointment_action.php">
                                            <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars(generateCsrfToken(), ENT_QUOTES, 'UTF-8'); ?>">
                                            <input type="hidden" name="action" value="cancel">
                                            <input type="hidden" name="appointment_id" value="<?php echo (int)$row['id']; ?>">
                                            <button class="btn btn-sm btn-outline-danger" type="submit">Cancel</button>
                                        </form>
                                    <?php else: ?>
                                        <span class="text-secondary small">-</span>
                                    <?php endif; ?>
                                </td>
                            </tr>
                        <?php endforeach; endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
<?php include __DIR__ . '/../includes/footer.php'; ?>
