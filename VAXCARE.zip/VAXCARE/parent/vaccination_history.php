<?php
require_once __DIR__ . '/../includes/auth.php';
requireRole(['parent']);
$pageTitle = 'Vaccination History';
$pdo = getDb();
$parent = fetchParentByUserId((int)currentUser()['id']);
$records = $pdo->prepare('SELECT vr.*, c.name AS child_name, v.name AS vaccine_name, h.hospital_name FROM vaccination_records vr LEFT JOIN children c ON c.id = vr.child_id LEFT JOIN vaccines v ON v.id = vr.vaccine_id LEFT JOIN hospitals h ON h.id = vr.hospital_id WHERE vr.child_id IN (SELECT id FROM children WHERE parent_id = :parent_id) ORDER BY vr.vaccination_date DESC');
$records->execute([':parent_id' => (int)$parent['id']]);
$history = $records->fetchAll();
include __DIR__ . '/../includes/header.php';
?>
<div class="dashboard-shell">
    <?php include __DIR__ . '/../includes/parent_sidebar.php'; ?>
    <div class="content-panel">
        <h2 class="mb-3">Vaccination History</h2>
        <div class="card p-3">
            <div class="table-responsive">
                <table class="table mb-0">
                    <thead><tr><th>Child</th><th>Vaccine</th><th>Hospital</th><th>Date</th><th>Status</th></tr></thead>
                    <tbody>
                        <?php if (!$history): ?>
                            <tr><td colspan="5" class="text-center text-secondary">No vaccination records found.</td></tr>
                        <?php else: foreach ($history as $record): ?>
                            <tr>
                                <td><?php echo htmlspecialchars($record['child_name']); ?></td>
                                <td><?php echo htmlspecialchars($record['vaccine_name']); ?></td>
                                <td><?php echo htmlspecialchars($record['hospital_name']); ?></td>
                                <td><?php echo formatDate($record['vaccination_date']); ?></td>
                                <td><?php echo htmlspecialchars($record['status']); ?></td>
                            </tr>
                        <?php endforeach; endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
<?php include __DIR__ . '/../includes/footer.php'; ?>
