<?php
require_once __DIR__ . '/../includes/auth.php';
requireRole(['parent']);
$pageTitle = 'My Children';
$pdo = getDb();
$parent = fetchParentByUserId((int)currentUser()['id']);
$children = $pdo->prepare('SELECT * FROM children WHERE parent_id = :parent_id ORDER BY created_at DESC');
$children->execute([':parent_id' => (int)$parent['id']]);
$childrenRows = $children->fetchAll();
include __DIR__ . '/../includes/header.php';
?>
<div class="dashboard-shell">
    <?php include __DIR__ . '/../includes/parent_sidebar.php'; ?>
    <div class="content-panel">
        <div class="d-flex justify-content-between align-items-center mb-3">
            <h2 class="mb-0">My Children</h2>
            <a class="btn btn-primary" href="child_form.php">Add Child</a>
        </div>
        <?php displayFlash(); ?>
        <div class="row g-4">
            <?php if (!$childrenRows): ?>
                <div class="col-12"><div class="empty-state card">No child profiles have been added yet.</div></div>
            <?php else: foreach ($childrenRows as $child): ?>
                <div class="col-md-6">
                    <div class="card p-4 h-100">
                        <div class="d-flex justify-content-between align-items-center mb-2">
                            <h5 class="mb-0"><?php echo htmlspecialchars($child['name']); ?></h5>
                            <span class="status-badge status-<?php echo htmlspecialchars($child['status']); ?>"><?php echo htmlspecialchars($child['status']); ?></span>
                        </div>
                        <p class="mb-1"><strong>Gender:</strong> <?php echo htmlspecialchars($child['gender']); ?></p>
                        <p class="mb-1"><strong>DOB:</strong> <?php echo formatDate($child['date_of_birth']); ?></p>
                        <p class="text-secondary mb-3"><?php echo htmlspecialchars($child['medical_notes'] ?: 'No additional medical notes'); ?></p>
                        <a class="btn btn-outline-primary btn-sm" href="child_form.php?id=<?php echo (int)$child['id']; ?>">Edit</a>
                    </div>
                </div>
            <?php endforeach; endif; ?>
        </div>
    </div>
</div>
<?php include __DIR__ . '/../includes/footer.php'; ?>
