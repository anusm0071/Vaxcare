<?php
require_once __DIR__ . '/../includes/auth.php';
requireRole(['parent']);
$pageTitle = 'Notifications';
$pdo = getDb();
$stmt = $pdo->prepare('SELECT * FROM notifications WHERE user_id = :user_id ORDER BY created_at DESC');
$stmt->execute([':user_id' => (int)currentUser()['id']]);
$notifications = $stmt->fetchAll();
include __DIR__ . '/../includes/header.php';
?>
<div class="dashboard-shell">
    <?php include __DIR__ . '/../includes/parent_sidebar.php'; ?>
    <div class="content-panel">
        <h2 class="mb-3">Notifications</h2>
        <?php displayFlash(); ?>
        <div class="card p-3">
            <?php if (!$notifications): ?>
                <div class="text-secondary text-center py-4">No notifications.</div>
            <?php else: foreach ($notifications as $n): ?>
                <div class="border rounded p-3 mb-3">
                    <div class="d-flex justify-content-between">
                        <strong><?php echo htmlspecialchars($n['title']); ?></strong>
                        <span class="small text-secondary"><?php echo formatDate($n['created_at']); ?></span>
                    </div>
                    <p class="mb-2 text-secondary"><?php echo htmlspecialchars($n['message']); ?></p>
                    <?php if ((int)$n['is_read'] === 0): ?>
                        <form method="POST" action="../actions/notification_action.php">
                            <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars(generateCsrfToken(), ENT_QUOTES, 'UTF-8'); ?>">
                            <input type="hidden" name="action" value="mark_read">
                            <input type="hidden" name="notification_id" value="<?php echo (int)$n['id']; ?>">
                            <button type="submit" class="btn btn-sm btn-outline-primary">Mark as read</button>
                        </form>
                    <?php endif; ?>
                </div>
            <?php endforeach; endif; ?>
        </div>
    </div>
</div>
<?php include __DIR__ . '/../includes/footer.php'; ?>
