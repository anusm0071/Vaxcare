<?php
require_once __DIR__ . '/../includes/auth.php';
requireRole(['parent']);
$pageTitle = 'Child Form';
$child = null;
$childId = (int)($_GET['id'] ?? 0);
if ($childId > 0) {
    $pdo = getDb();
    $stmt = $pdo->prepare('SELECT * FROM children WHERE id = :id AND parent_id = (SELECT id FROM parents WHERE user_id = :user_id) LIMIT 1');
    $stmt->execute([':id' => $childId, ':user_id' => (int)currentUser()['id']]);
    $child = $stmt->fetch();
}
include __DIR__ . '/../includes/header.php';
?>
<div class="dashboard-shell">
    <?php include __DIR__ . '/../includes/parent_sidebar.php'; ?>
    <div class="content-panel">
        <h2 class="mb-3"><?php echo $child ? 'Edit Child' : 'Add Child'; ?></h2>
        <div class="card p-4">
            <form method="POST" action="../actions/child_action.php">
                <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars(generateCsrfToken(), ENT_QUOTES, 'UTF-8'); ?>">
                <?php if ($child): ?><input type="hidden" name="id" value="<?php echo (int)$child['id']; ?>"><?php endif; ?>
                <div class="row g-3">
                    <div class="col-md-6">
                        <label class="form-label">Child Name</label>
                        <input type="text" class="form-control" name="name" value="<?php echo htmlspecialchars($child['name'] ?? ''); ?>" required>
                    </div>
                    <div class="col-md-6">
                        <label class="form-label">Date of Birth</label>
                        <input type="date" class="form-control" name="date_of_birth" value="<?php echo htmlspecialchars($child['date_of_birth'] ?? ''); ?>" required>
                    </div>
                    <div class="col-md-6">
                        <label class="form-label">Gender</label>
                        <select class="form-select" name="gender" required>
                            <option value="Male" <?php echo (($child['gender'] ?? '') === 'Male') ? 'selected' : ''; ?>>Male</option>
                            <option value="Female" <?php echo (($child['gender'] ?? '') === 'Female') ? 'selected' : ''; ?>>Female</option>
                            <option value="Other" <?php echo (($child['gender'] ?? '') === 'Other') ? 'selected' : ''; ?>>Other</option>
                        </select>
                    </div>
                    <div class="col-md-6">
                        <label class="form-label">Allergies</label>
                        <input type="text" class="form-control" name="allergies" value="<?php echo htmlspecialchars($child['allergies'] ?? ''); ?>">
                    </div>
                    <div class="col-12">
                        <label class="form-label">Medical Notes</label>
                        <textarea class="form-control" rows="4" name="medical_notes"><?php echo htmlspecialchars($child['medical_notes'] ?? ''); ?></textarea>
                    </div>
                </div>
                <button class="btn btn-primary mt-3" type="submit">Save Child</button>
            </form>
        </div>
    </div>
</div>
<?php include __DIR__ . '/../includes/footer.php'; ?>
