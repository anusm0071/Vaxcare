<?php
require_once __DIR__ . '/../includes/auth.php';
requireRole(['parent']);
$pageTitle = 'Parent Dashboard';
$pdo = getDb();
$user = currentUser();
$parent = fetchParentByUserId((int)$user['id']);
$childCount = (int) $pdo->query('SELECT COUNT(*) FROM children WHERE parent_id = ' . (int)$parent['id'] . ' AND status = "active"')->fetchColumn();
$appointmentCount = (int) $pdo->query('SELECT COUNT(*) FROM appointments WHERE parent_id = ' . (int)$parent['id'])->fetchColumn();
$upcoming = $pdo->prepare('SELECT a.*, c.name AS child_name, h.hospital_name, v.name AS vaccine_name FROM appointments a LEFT JOIN children c ON c.id = a.child_id LEFT JOIN hospitals h ON h.id = a.hospital_id LEFT JOIN vaccines v ON v.id = a.vaccine_id WHERE a.parent_id = :parent_id AND a.appointment_date >= CURDATE() ORDER BY a.appointment_date ASC LIMIT 5');
$upcoming->execute([':parent_id' => (int)$parent['id']]);
$upcomingRows = $upcoming->fetchAll();
$notifications = $pdo->prepare('SELECT * FROM notifications WHERE user_id = :user_id ORDER BY created_at DESC LIMIT 5');
$notifications->execute([':user_id' => (int)$user['id']]);
$notificationRows = $notifications->fetchAll();
include __DIR__ . '/../includes/header.php';
?>
<div class="dashboard-shell">
    <?php include __DIR__ . '/../includes/parent_sidebar.php'; ?>
    <div class="content-panel">
        <h2 class="mb-3">Welcome, <?php echo htmlspecialchars($user['name']); ?></h2>
        <?php displayFlash(); ?>
        <div class="row g-4 mb-4">
            <div class="col-md-4">
                <div class="stat-card">
                    <div class="d-flex justify-content-between align-items-center">
                        <div>
                            <div class="text-secondary small">My Children</div>
                            <div class="fs-3 fw-bold"><?php echo $childCount; ?></div>
                        </div>
                        <div class="stat-icon"><i class="bi bi-people"></i></div>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="stat-card">
                    <div class="d-flex justify-content-between align-items-center">
                        <div>
                            <div class="text-secondary small">Appointments</div>
                            <div class="fs-3 fw-bold"><?php echo $appointmentCount; ?></div>
                        </div>
                        <div class="stat-icon"><i class="bi bi-calendar-check"></i></div>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="stat-card">
                    <div class="d-flex justify-content-between align-items-center">
                        <div>
                            <div class="text-secondary small">Notifications</div>
                            <div class="fs-3 fw-bold"><?php echo count($notificationRows); ?></div>
                        </div>
                        <div class="stat-icon"><i class="bi bi-bell"></i></div>
                    </div>
                </div>
            </div>
        </div>

        <div class="row g-4">
            <div class="col-lg-7">
                <div class="card p-3">
                    <h5 class="mb-3">Upcoming vaccinations</h5>
                    <div class="table-responsive">
                        <table class="table table-hover mb-0">
                            <thead><tr><th>Child</th><th>Hospital</th><th>Vaccine</th><th>Date</th></tr></thead>
                            <tbody>
                                <?php if (!$upcomingRows): ?>
                                    <tr><td colspan="4" class="text-center text-secondary">No upcoming appointments.</td></tr>
                                <?php else: foreach ($upcomingRows as $row): ?>
                                    <tr>
                                        <td><?php echo htmlspecialchars($row['child_name']); ?></td>
                                        <td><?php echo htmlspecialchars($row['hospital_name']); ?></td>
                                        <td><?php echo htmlspecialchars($row['vaccine_name']); ?></td>
                                        <td><?php echo formatDate($row['appointment_date']); ?></td>
                                    </tr>
                                <?php endforeach; endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
            <div class="col-lg-5">
                <div class="card p-3">
                    <h5 class="mb-3">Latest notifications</h5>
                    <div class="list-group list-group-flush">
                        <?php if (!$notificationRows): ?>
                            <div class="text-secondary text-center py-3">No notifications yet.</div>
                        <?php else: foreach ($notificationRows as $n): ?>
                            <div class="list-group-item">
                                <div class="fw-bold"><?php echo htmlspecialchars($n['title']); ?></div>
                                <div class="small text-secondary"><?php echo htmlspecialchars($n['message']); ?></div>
                            </div>
                        <?php endforeach; endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php include __DIR__ . '/../includes/footer.php'; ?>
