<?php
require_once __DIR__ . '/../includes/auth.php';
requireRole(['parent']);
$pageTitle = 'Parent Profile';
$user = currentUser();
$pdo = getDb();
$parent = fetchParentByUserId((int)$user['id']);
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = sanitizeString($_POST['name'] ?? '');
    $phone = sanitizeString($_POST['phone'] ?? '');
    $address = sanitizeString($_POST['address'] ?? '');
    $city = sanitizeString($_POST['city'] ?? '');
    if ($name !== '' && validatePhone($phone)) {
        $pdo->prepare('UPDATE users SET name = :name, phone = :phone, updated_at = NOW() WHERE id = :id')->execute([':name' => $name, ':phone' => $phone, ':id' => (int)$user['id']]);
        $pdo->prepare('UPDATE parents SET address = :address, city = :city, phone = :phone, updated_at = NOW() WHERE user_id = :user_id')->execute([':address' => $address, ':city' => $city, ':phone' => $phone, ':user_id' => (int)$user['id']]);
        flash('success', 'Profile updated successfully.');
        redirect('profile.php');
    }
    flash('error', 'Please provide valid profile details.');
}
include __DIR__ . '/../includes/header.php';
?>
<div class="dashboard-shell">
    <?php include __DIR__ . '/../includes/parent_sidebar.php'; ?>
    <div class="content-panel">
        <h2 class="mb-3">My Profile</h2>
        <?php displayFlash(); ?>
        <div class="card p-4">
            <form method="POST">
                <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars(generateCsrfToken(), ENT_QUOTES, 'UTF-8'); ?>">
                <div class="row g-3">
                    <div class="col-md-6">
                        <label class="form-label">Full Name</label>
                        <input type="text" class="form-control" name="name" value="<?php echo htmlspecialchars($user['name']); ?>" required>
                    </div>
                    <div class="col-md-6">
                        <label class="form-label">Phone</label>
                        <input type="text" class="form-control" name="phone" value="<?php echo htmlspecialchars($parent['phone'] ?? ''); ?>" required>
                    </div>
                    <div class="col-md-6">
                        <label class="form-label">Address</label>
                        <input type="text" class="form-control" name="address" value="<?php echo htmlspecialchars($parent['address'] ?? ''); ?>">
                    </div>
                    <div class="col-md-6">
                        <label class="form-label">City</label>
                        <input type="text" class="form-control" name="city" value="<?php echo htmlspecialchars($parent['city'] ?? ''); ?>">
                    </div>
                </div>
                <button class="btn btn-primary mt-3" type="submit">Update Profile</button>
            </form>
        </div>
    </div>
</div>
<?php include __DIR__ . '/../includes/footer.php'; ?>
