<?php
require_once __DIR__ . '/../includes/auth.php';
requireRole(['parent']);
$pageTitle = 'Hospital Details';
$pdo = getDb();
$hospitalId = (int)($_GET['id'] ?? 0);
$hospital = $pdo->prepare('SELECT * FROM hospitals WHERE id = :id AND status = "active" LIMIT 1');
$hospital->execute([':id' => $hospitalId]);
$hospitalRow = $hospital->fetch();
$inventory = $pdo->prepare('SELECT i.*, v.name AS vaccine_name FROM hospital_vaccine_inventory i LEFT JOIN vaccines v ON v.id = i.vaccine_id WHERE i.hospital_id = :hospital_id AND i.status = "active" ORDER BY v.name');
$inventory->execute([':hospital_id' => $hospitalId]);
$inventoryRows = $inventory->fetchAll();
include __DIR__ . '/../includes/header.php';
?>
<div class="dashboard-shell">
    <?php include __DIR__ . '/../includes/parent_sidebar.php'; ?>
    <div class="content-panel">
        <?php if (!$hospitalRow): ?>
            <div class="alert alert-warning">Hospital not found.</div>
        <?php else: ?>
            <h2 class="mb-3"><?php echo htmlspecialchars($hospitalRow['hospital_name']); ?></h2>
            <div class="card p-4 mb-4">
                <p class="mb-1"><strong>Address:</strong> <?php echo htmlspecialchars($hospitalRow['address'] ?? 'Not available'); ?></p>
                <p class="mb-1"><strong>City:</strong> <?php echo htmlspecialchars($hospitalRow['city']); ?></p>
                <p class="mb-1"><strong>Phone:</strong> <?php echo htmlspecialchars($hospitalRow['phone']); ?></p>
                <p class="mb-0"><strong>Email:</strong> <?php echo htmlspecialchars($hospitalRow['email']); ?></p>
            </div>
            <div class="card p-3">
                <h5 class="mb-3">Available Vaccines</h5>
                <div class="table-responsive">
                    <table class="table mb-0">
                        <thead><tr><th>Vaccine</th><th>Stock</th><th>Availability</th></tr></thead>
                        <tbody>
                            <?php if (!$inventoryRows): ?>
                                <tr><td colspan="3" class="text-center text-secondary">No vaccine inventory available.</td></tr>
                            <?php else: foreach ($inventoryRows as $item): ?>
                                <tr>
                                    <td><?php echo htmlspecialchars($item['vaccine_name']); ?></td>
                                    <td><?php echo (int)$item['stock']; ?></td>
                                    <td><?php echo htmlspecialchars($item['status']); ?></td>
                                </tr>
                            <?php endforeach; endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        <?php endif; ?>
    </div>
</div>
<?php include __DIR__ . '/../includes/footer.php'; ?>
