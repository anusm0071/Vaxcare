<?php
require_once __DIR__ . '/../includes/auth.php';
requireRole(['parent']);
$pageTitle = 'Find Hospitals';
$pdo = getDb();
$search = sanitizeString($_GET['search'] ?? '');
if ($search !== '') {
    $stmt = $pdo->prepare('SELECT * FROM hospitals WHERE status = "active" AND (hospital_name LIKE :search OR city LIKE :search OR address LIKE :search) ORDER BY hospital_name ASC');
    $searchTerm = '%' . $search . '%';
    $stmt->execute([':search' => $searchTerm]);
    $hospitals = $stmt->fetchAll();
} else {
    $hospitals = $pdo->query('SELECT * FROM hospitals WHERE status = "active" ORDER BY hospital_name ASC')->fetchAll();
}
include __DIR__ . '/../includes/header.php';
?>
<div class="dashboard-shell">
    <?php include __DIR__ . '/../includes/parent_sidebar.php'; ?>
    <div class="content-panel">
        <h2 class="mb-3">Search Hospitals</h2>
        <form method="GET" class="card p-3 mb-4">
            <div class="row g-2 align-items-end">
                <div class="col-md-10">
                    <label class="form-label">Search by name or city</label>
                    <input type="text" class="form-control" name="search" value="<?php echo htmlspecialchars($search); ?>">
                </div>
                <div class="col-md-2">
                    <button class="btn btn-primary w-100" type="submit">Search</button>
                </div>
            </div>
        </form>
        <div class="row g-4">
            <?php if (!$hospitals): ?>
                <div class="col-12"><div class="empty-state card">No hospitals matched your search.</div></div>
            <?php else: foreach ($hospitals as $hospital): ?>
                <div class="col-md-6 col-xl-4">
                    <div class="card p-4 h-100">
                        <h5><?php echo htmlspecialchars($hospital['hospital_name']); ?></h5>
                        <p class="text-secondary mb-2"><?php echo htmlspecialchars($hospital['address'] ?? 'Address not listed'); ?></p>
                        <p class="mb-1"><i class="bi bi-geo-alt"></i> <?php echo htmlspecialchars($hospital['city']); ?></p>
                        <p class="mb-1"><i class="bi bi-telephone"></i> <?php echo htmlspecialchars($hospital['phone']); ?></p>
                        <a href="hospital_details.php?id=<?php echo (int)$hospital['id']; ?>" class="btn btn-outline-primary btn-sm mt-3">View Details</a>
                    </div>
                </div>
            <?php endforeach; endif; ?>
        </div>
    </div>
</div>
<?php include __DIR__ . '/../includes/footer.php'; ?>
