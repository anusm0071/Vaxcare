<?php
require_once __DIR__ . '/../includes/auth.php';
requireRole(['parent']);
$pageTitle = 'Book Appointment';
$pdo = getDb();
$parent = fetchParentByUserId((int)currentUser()['id']);
$children = $pdo->prepare('SELECT * FROM children WHERE parent_id = :parent_id AND status = "active" ORDER BY name ASC');
$children->execute([':parent_id' => (int)$parent['id']]);
$childrenRows = $children->fetchAll();
$hospitals = $pdo->query('SELECT * FROM hospitals WHERE status = "active" ORDER BY hospital_name ASC')->fetchAll();
$vaccines = $pdo->query('SELECT * FROM vaccines WHERE status = "active" ORDER BY name ASC')->fetchAll();
include __DIR__ . '/../includes/header.php';
?>
<div class="dashboard-shell">
    <?php include __DIR__ . '/../includes/parent_sidebar.php'; ?>
    <div class="content-panel">
        <h2 class="mb-3">Book Vaccination Appointment</h2>
        <?php displayFlash(); ?>
        <div class="card p-4">
            <form method="POST" action="../actions/appointment_action.php">
                <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars(generateCsrfToken(), ENT_QUOTES, 'UTF-8'); ?>">
                <div class="row g-3">
                    <div class="col-md-6">
                        <label class="form-label">Select Child</label>
                        <select class="form-select" name="child_id" required>
                            <?php foreach ($childrenRows as $child): ?>
                                <option value="<?php echo (int)$child['id']; ?>"><?php echo htmlspecialchars($child['name']); ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="col-md-6">
                        <label class="form-label">Select Vaccine</label>
                        <select class="form-select" name="vaccine_id" required>
                            <?php foreach ($vaccines as $vaccine): ?>
                                <option value="<?php echo (int)$vaccine['id']; ?>"><?php echo htmlspecialchars($vaccine['name']); ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="col-md-6">
                        <label class="form-label">Choose Hospital</label>
                        <select class="form-select" name="hospital_id" required>
                            <?php foreach ($hospitals as $hospital): ?>
                                <option value="<?php echo (int)$hospital['id']; ?>"><?php echo htmlspecialchars($hospital['hospital_name']); ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="col-md-3">
                        <label class="form-label">Appointment Date</label>
                        <input type="date" class="form-control" name="appointment_date" required>
                    </div>
                    <div class="col-md-3">
                        <label class="form-label">Time Slot</label>
                        <select class="form-select" name="slot_time">
                            <option value="09:00">09:00</option>
                            <option value="10:30">10:30</option>
                            <option value="12:00">12:00</option>
                            <option value="14:00">14:00</option>
                            <option value="15:30">15:30</option>
                        </select>
                    </div>
                </div>
                <button class="btn btn-primary mt-3" type="submit">Submit Request</button>
            </form>
        </div>
    </div>
</div>
<?php include __DIR__ . '/../includes/footer.php'; ?>
