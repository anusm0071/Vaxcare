<?php
require_once __DIR__ . '/includes/header.php';
$pageTitle = 'Login';
?>
<section class="py-5">
    <div class="container">
        <div class="card auth-card shadow-sm border-0 p-4">
            <h2 class="text-center mb-4">Login</h2>
            <?php displayFlash(); ?>
            <form method="POST" action="actions/login_action.php">
                <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars(generateCsrfToken(), ENT_QUOTES, 'UTF-8'); ?>">
                <div class="mb-3">
                    <label class="form-label">Email</label>
                    <input type="email" class="form-control" name="email" required>
                </div>
                <div class="mb-3">
                    <label class="form-label">Password</label>
                    <input type="password" class="form-control" name="password" required>
                </div>
                <button class="btn btn-primary w-100" type="submit">Login</button>
            </form>
            <p class="text-center mt-3 mb-0">Need an account? <a href="register.php">Register here</a></p>
        </div>
    </div>
</section>
<?php include __DIR__ . '/includes/footer.php'; ?>
