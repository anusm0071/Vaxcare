<?php
require_once __DIR__ . '/includes/header.php';
$pageTitle = 'About Us';
?>
<section class="py-5">
    <div class="container">
        <div class="row align-items-center">
            <div class="col-lg-6">
                <h1 class="section-title">About VAXCARE</h1>
                <p class="text-secondary">VAXCARE is a secure healthcare administration system designed for managing child vaccination records, hospital bookings, and compliance reporting for public health teams.</p>
                <p class="text-secondary">Our goal is to simplify information management while helping parents and hospitals stay on schedule with vaccination plans.</p>
            </div>
            <div class="col-lg-6">
                <img src="https://images.unsplash.com/photo-1516549655169-df83a0774514?auto=format&fit=crop&w=900&q=80" class="img-fluid rounded-4" alt="Healthcare team" />
            </div>
        </div>
    </div>
</section>
<?php include __DIR__ . '/includes/footer.php'; ?>
