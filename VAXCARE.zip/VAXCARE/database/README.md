# Database Setup

1. Start Apache and MySQL in XAMPP.
2. Open phpMyAdmin or MySQL CLI.
3. Import this SQL file into a database named `vaccination_management`.
4. Verify the database tables and seeded sample data.
5. Copy `.env.example` to `.env` and update the values if needed.

The project expects a local MySQL database with the credentials from `.env`.
