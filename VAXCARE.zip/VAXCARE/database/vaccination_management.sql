CREATE DATABASE IF NOT EXISTS vaccination_management;
USE vaccination_management;

DROP TABLE IF EXISTS contact_messages;
DROP TABLE IF EXISTS audit_logs;
DROP TABLE IF EXISTS notifications;
DROP TABLE IF EXISTS vaccination_records;
DROP TABLE IF EXISTS appointments;
DROP TABLE IF EXISTS hospital_vaccine_inventory;
DROP TABLE IF EXISTS vaccination_schedules;
DROP TABLE IF EXISTS vaccines;
DROP TABLE IF EXISTS children;
DROP TABLE IF EXISTS hospitals;
DROP TABLE IF EXISTS parents;
DROP TABLE IF EXISTS users;

CREATE TABLE users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(150) NOT NULL,
    email VARCHAR(150) NOT NULL UNIQUE,
    password_hash VARCHAR(255) NOT NULL,
    phone VARCHAR(30) DEFAULT NULL,
    role ENUM('admin','parent','hospital') NOT NULL,
    status ENUM('active','inactive') NOT NULL DEFAULT 'active',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_users_role (role),
    INDEX idx_users_email (email)
) ENGINE=InnoDB;

CREATE TABLE parents (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL UNIQUE,
    address VARCHAR(255) DEFAULT NULL,
    city VARCHAR(100) DEFAULT NULL,
    phone VARCHAR(30) DEFAULT NULL,
    status ENUM('active','inactive') NOT NULL DEFAULT 'active',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    CONSTRAINT fk_parents_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE TABLE hospitals (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT DEFAULT NULL UNIQUE,
    hospital_name VARCHAR(150) NOT NULL,
    address VARCHAR(255) DEFAULT NULL,
    city VARCHAR(100) DEFAULT NULL,
    phone VARCHAR(30) DEFAULT NULL,
    email VARCHAR(150) DEFAULT NULL,
    status ENUM('active','inactive') NOT NULL DEFAULT 'active',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    CONSTRAINT fk_hospitals_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL,
    INDEX idx_hospitals_city (city)
) ENGINE=InnoDB;

CREATE TABLE children (
    id INT AUTO_INCREMENT PRIMARY KEY,
    parent_id INT NOT NULL,
    name VARCHAR(150) NOT NULL,
    date_of_birth DATE NOT NULL,
    gender ENUM('Male','Female','Other') NOT NULL,
    allergies VARCHAR(255) DEFAULT NULL,
    medical_notes TEXT DEFAULT NULL,
    status ENUM('active','inactive') NOT NULL DEFAULT 'active',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    CONSTRAINT fk_children_parent FOREIGN KEY (parent_id) REFERENCES parents(id) ON DELETE CASCADE,
    INDEX idx_children_parent (parent_id)
) ENGINE=InnoDB;

CREATE TABLE vaccines (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(150) NOT NULL UNIQUE,
    description TEXT DEFAULT NULL,
    status ENUM('active','inactive') NOT NULL DEFAULT 'active',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_vaccines_status (status)
) ENGINE=InnoDB;

CREATE TABLE vaccination_schedules (
    id INT AUTO_INCREMENT PRIMARY KEY,
    vaccine_id INT NOT NULL,
    dose_number INT NOT NULL,
    recommended_age_months INT NOT NULL,
    description TEXT DEFAULT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    CONSTRAINT fk_schedule_vaccine FOREIGN KEY (vaccine_id) REFERENCES vaccines(id) ON DELETE CASCADE,
    INDEX idx_schedule_age (recommended_age_months)
) ENGINE=InnoDB;

CREATE TABLE hospital_vaccine_inventory (
    id INT AUTO_INCREMENT PRIMARY KEY,
    hospital_id INT NOT NULL,
    vaccine_id INT NOT NULL,
    stock INT NOT NULL DEFAULT 0,
    status ENUM('active','inactive') NOT NULL DEFAULT 'active',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    UNIQUE KEY uniq_hospital_vaccine (hospital_id, vaccine_id),
    CONSTRAINT fk_inventory_hospital FOREIGN KEY (hospital_id) REFERENCES hospitals(id) ON DELETE CASCADE,
    CONSTRAINT fk_inventory_vaccine FOREIGN KEY (vaccine_id) REFERENCES vaccines(id) ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE TABLE appointments (
    id INT AUTO_INCREMENT PRIMARY KEY,
    child_id INT NOT NULL,
    parent_id INT NOT NULL,
    hospital_id INT NOT NULL,
    vaccine_id INT NOT NULL,
    appointment_date DATE NOT NULL,
    slot_time TIME NOT NULL,
    status ENUM('Pending','Approved','Rejected','Completed','Cancelled') NOT NULL DEFAULT 'Pending',
    rejection_reason VARCHAR(255) DEFAULT NULL,
    notes TEXT DEFAULT NULL,
    requested_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    approved_at TIMESTAMP NULL DEFAULT NULL,
    completed_at TIMESTAMP NULL DEFAULT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    CONSTRAINT fk_appointments_child FOREIGN KEY (child_id) REFERENCES children(id) ON DELETE CASCADE,
    CONSTRAINT fk_appointments_parent FOREIGN KEY (parent_id) REFERENCES parents(id) ON DELETE CASCADE,
    CONSTRAINT fk_appointments_hospital FOREIGN KEY (hospital_id) REFERENCES hospitals(id) ON DELETE CASCADE,
    CONSTRAINT fk_appointments_vaccine FOREIGN KEY (vaccine_id) REFERENCES vaccines(id) ON DELETE RESTRICT,
    INDEX idx_appointments_date (appointment_date),
    INDEX idx_appointments_status (status)
) ENGINE=InnoDB;

CREATE TABLE vaccination_records (
    id INT AUTO_INCREMENT PRIMARY KEY,
    appointment_id INT NOT NULL,
    child_id INT NOT NULL,
    hospital_id INT NOT NULL,
    vaccine_id INT NOT NULL,
    dose_number INT NOT NULL,
    vaccination_date DATE NOT NULL,
    notes TEXT DEFAULT NULL,
    status ENUM('Completed','Missed','Delayed') NOT NULL DEFAULT 'Completed',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_records_appointment FOREIGN KEY (appointment_id) REFERENCES appointments(id) ON DELETE CASCADE,
    CONSTRAINT fk_records_child FOREIGN KEY (child_id) REFERENCES children(id) ON DELETE CASCADE,
    CONSTRAINT fk_records_hospital FOREIGN KEY (hospital_id) REFERENCES hospitals(id) ON DELETE CASCADE,
    CONSTRAINT fk_records_vaccine FOREIGN KEY (vaccine_id) REFERENCES vaccines(id) ON DELETE RESTRICT,
    INDEX idx_records_child (child_id),
    INDEX idx_records_date (vaccination_date)
) ENGINE=InnoDB;

CREATE TABLE notifications (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    title VARCHAR(255) NOT NULL,
    message TEXT NOT NULL,
    type ENUM('info','success','warning','error') NOT NULL DEFAULT 'info',
    is_read TINYINT(1) NOT NULL DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_notifications_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    INDEX idx_notifications_user (user_id)
) ENGINE=InnoDB;

CREATE TABLE audit_logs (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT DEFAULT NULL,
    action VARCHAR(100) NOT NULL,
    entity_type VARCHAR(100) DEFAULT NULL,
    entity_id INT DEFAULT NULL,
    details TEXT DEFAULT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_audit_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL,
    INDEX idx_audit_user (user_id)
) ENGINE=InnoDB;

CREATE TABLE contact_messages (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(150) NOT NULL,
    email VARCHAR(150) NOT NULL,
    subject VARCHAR(255) NOT NULL,
    message TEXT NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_contact_email (email)
) ENGINE=InnoDB;

INSERT INTO users (name, email, password_hash, phone, role, status, created_at, updated_at) VALUES
('System Admin', 'admin@vaxcare.local', '$2y$10$gEbWcVPMK.fRB9ngMUMw/O9McZCxB7AL49c0jQAErcII6RpsQoUn.', '+923001234567', 'admin', 'active', NOW(), NOW()),
('Ayesha Khan', 'parent@vaxcare.local', '$2y$10$DZIcoh9SXZJ7BbCF5D94Z.I3c5jt0kfQK53xgY0Cm2WKdbXihQ2AK', '+923004567890', 'parent', 'active', NOW(), NOW()),
('CityCare Hospital', 'hospital@vaxcare.local', '$2y$10$/oiFhAyYLs9A47EqiNp5yOfQDs9jIbBLUS9ECqDd53oacuJFMJH2K', '+923009876543', 'hospital', 'active', NOW(), NOW());

INSERT INTO parents (user_id, address, city, phone, status, created_at, updated_at) VALUES
(2, '12 Gulshan Avenue', 'Lahore', '+923004567890', 'active', NOW(), NOW());

INSERT INTO hospitals (user_id, hospital_name, address, city, phone, email, status, created_at, updated_at) VALUES
(3, 'CityCare Hospital', '15 Wellness Road', 'Lahore', '+923009876543', 'hospital@vaxcare.local', 'active', NOW(), NOW());

INSERT INTO children (parent_id, name, date_of_birth, gender, allergies, medical_notes, status, created_at, updated_at) VALUES
(1, 'Ali Khan', '2020-03-15', 'Male', 'None', 'Healthy, regular checkups', 'active', NOW(), NOW()),
(1, 'Sara Khan', '2018-07-21', 'Female', 'Peanuts', 'Needs yearly review', 'active', NOW(), NOW());

INSERT INTO vaccines (name, description, status, created_at, updated_at) VALUES
('Hepatitis B', 'Vaccination against hepatitis B infection', 'active', NOW(), NOW()),
('Polio', 'Oral/inactivated polio vaccine', 'active', NOW(), NOW()),
('MMR', 'Measles, Mumps and Rubella vaccine', 'active', NOW(), NOW()),
('DTP', 'Diphtheria, Tetanus and Pertussis vaccine', 'active', NOW(), NOW());

INSERT INTO vaccination_schedules (vaccine_id, dose_number, recommended_age_months, description, created_at, updated_at) VALUES
(1, 1, 0, 'Birth dose when available', NOW(), NOW()),
(2, 1, 2, 'First dose for routine protection', NOW(), NOW()),
(3, 1, 12, 'Routine childhood immunization check', NOW(), NOW()),
(4, 1, 6, 'Initial childhood protection dose', NOW(), NOW());

INSERT INTO hospital_vaccine_inventory (hospital_id, vaccine_id, stock, status, created_at, updated_at) VALUES
(1, 1, 40, 'active', NOW(), NOW()),
(1, 2, 30, 'active', NOW(), NOW()),
(1, 3, 18, 'active', NOW(), NOW()),
(1, 4, 25, 'active', NOW(), NOW());

INSERT INTO appointments (child_id, parent_id, hospital_id, vaccine_id, appointment_date, slot_time, status, notes, requested_at, approved_at, created_at, updated_at) VALUES
(1, 1, 1, 1, DATE_ADD(CURDATE(), INTERVAL 3 DAY), '10:30:00', 'Pending', 'Awaiting review', NOW(), NULL, NOW(), NOW()),
(2, 1, 1, 3, DATE_ADD(CURDATE(), INTERVAL 1 DAY), '14:00:00', 'Approved', 'Confirmed by hospital', NOW(), NOW(), NOW(), NOW()),
(1, 1, 1, 2, DATE_SUB(CURDATE(), INTERVAL 3 DAY), '09:00:00', 'Completed', 'Vaccination delivered successfully', NOW(), NOW(), NOW(), NOW());

INSERT INTO vaccination_records (appointment_id, child_id, hospital_id, vaccine_id, dose_number, vaccination_date, notes, status, created_at) VALUES
(3, 1, 1, 2, 1, DATE_SUB(CURDATE(), INTERVAL 3 DAY), 'Routine polio vaccination carried out.', 'Completed', NOW());

INSERT INTO notifications (user_id, title, message, type, is_read, created_at) VALUES
(2, 'Appointment update', 'Your appointment request is awaiting review.', 'info', 0, NOW()),
(3, 'New appointment request', 'A parent has booked a vaccination visit.', 'info', 0, NOW());

INSERT INTO audit_logs (user_id, action, entity_type, entity_id, details, created_at) VALUES
(1, 'login', 'users', 1, 'System admin logged in successfully.', NOW()),
(2, 'child_added', 'children', 1, 'Parent registered a child profile.', NOW());

INSERT INTO contact_messages (name, email, subject, message, created_at) VALUES
('Sample Visitor', 'visitor@example.com', 'General Inquiry', 'This is a demonstration message stored by the contact form.', NOW());
