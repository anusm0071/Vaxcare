# GUI Standards Document

## Design Principles

- Clean healthcare styling
- Blue and white palette
- Card-based layout
- Clear labels and action buttons
- Mobile responsiveness

## Form Rules

- Use visible labels
- Required inputs must be clearly marked
- Provide success and error messages
- Use consistent button styles

## Dashboard Rules

- Group related functions in side navigation
- Use card stats for overview
- Display tables with readable spacing
- Use color-coded statuses
