# Algorithms and Flowcharts

## 1. Registration and Login

1. Take email, password and role from the form.
2. Validate the email and password length.
3. Check whether the email already exists.
4. Hash the password using `password_hash()`.
5. Store the user in the `users` table.
6. During login, verify the entered password with `password_verify()`.
7. Create a session and redirect the user to the correct dashboard.

## 2. Child Registration

1. Parent is authenticated.
2. Validate child details and date of birth.
3. Insert the child row linked to the parent.
4. Store allergies and medical notes.

## 3. Hospital Search

1. Read the search term from the request.
2. Match against hospital name, city and address.
3. Return matching hospitals.

## 4. Booking Submission

1. Validate child, hospital, vaccine and appointment date.
2. Check parent ownership of the child.
3. Insert the appointment with status `Pending`.
4. Notify the parent and admin of the new request.

## 5. Admin Approval or Rejection

1. Admin selects an appointment.
2. Verify the status is `Pending`.
3. Update the row to `Approved` or `Rejected`.
4. Save rejection reason when rejected.

## 6. Vaccination Status Update

1. Hospital verifies appointment ownership.
2. Update appointment status.
3. Create a vaccination record if the outcome is completed.
4. Save notes and date.

## 7. Upcoming Vaccination Calculation

1. Select appointments for the current user.
2. Filter by future dates.
3. Sort by date and show relevant vaccine and hospital details.

## 8. Report Generation

1. Read filtering parameters from the query string.
2. Build a SQL query using filters.
3. Execute the query and present the results in a table.
