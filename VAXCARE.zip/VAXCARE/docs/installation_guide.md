# Installation Guide

## Requirements

- PHP 8.0+
- MySQL 8.0+
- Apache or PHP built-in server
- Browser

## Step 1: Prepare the Project

Place the project folder in the web root. For XAMPP, use:

`c:/xampp/htdocs/VAXCARE`

## Step 2: Create Environment File

Copy `.env.example` to `.env` and update database values if needed.

## Step 3: Import the Database

Open phpMyAdmin or MySQL CLI and import the file:

`database/vaccination_management.sql`

## Step 4: Start the Server

Use PHP's built-in server:

```bash
php -S localhost:8000
```

Or run Apache from XAMPP.

## Step 5: Open the Application

Visit:

`http://localhost/VAXCARE/`

or

`http://localhost:8000/`

## Troubleshooting

- Check whether MySQL is running.
- Confirm the DB name and credentials in `.env`.
- Ensure the SQL file imported without errors.
- Review `php_errors.log` if needed.
