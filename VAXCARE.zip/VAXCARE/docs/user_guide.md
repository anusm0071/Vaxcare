# User Guide

## Admin

- Login with the admin credentials from the seed data.
- View summaries and appointment activity.
- Manage children, hospitals and vaccines.
- Approve or reject appointment requests.
- Generate reports.

## Parent

- Register a new account.
- Add child profiles.
- Search hospitals.
- Create vaccination booking requests.
- Review appointment status and medical history.

## Hospital

- Register or log in as a hospital user.
- Update hospital profile details.
- Review assigned appointments.
- Update appointment status and vaccination outcome.
- Manage vaccine stock.
