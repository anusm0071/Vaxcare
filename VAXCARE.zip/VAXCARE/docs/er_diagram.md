# ER Diagram

```mermaid
erDiagram
    USERS ||--o{ PARENTS : has
    USERS ||--o{ HOSPITALS : has
    PARENTS ||--o{ CHILDREN : owns
    USERS ||--o{ NOTIFICATIONS : receives
    CHILDREN ||--o{ APPOINTMENTS : has
    PARENTS ||--o{ APPOINTMENTS : requests
    HOSPITALS ||--o{ APPOINTMENTS : handles
    VACCINES ||--o{ APPOINTMENTS : used_in
    VACCINES ||--o{ VACCINATION_SCHEDULES : has
    HOSPITALS ||--o{ HOSPITAL_VACCINE_INVENTORY : stocks
    VACCINES ||--o{ HOSPITAL_VACCINE_INVENTORY : appears_in
    APPOINTMENTS ||--o| VACCINATION_RECORDS : creates
    CHILDREN ||--o{ VACCINATION_RECORDS : receives
    HOSPITALS ||--o{ VACCINATION_RECORDS : records

    USERS {
        int id PK
        varchar name
        varchar email
        varchar password_hash
        varchar phone
        enum role
        enum status
    }

    PARENTS {
        int id PK
        int user_id FK
        varchar city
        varchar address
    }

    HOSPITALS {
        int id PK
        int user_id FK
        varchar hospital_name
        varchar city
        varchar phone
    }

    CHILDREN {
        int id PK
        int parent_id FK
        varchar name
        date date_of_birth
        enum gender
    }

    VACCINES {
        int id PK
        varchar name
        text description
    }

    VACCINATION_SCHEDULES {
        int id PK
        int vaccine_id FK
        int dose_number
        int recommended_age_months
    }

    HOSPITAL_VACCINE_INVENTORY {
        int id PK
        int hospital_id FK
        int vaccine_id FK
        int stock
    }

    APPOINTMENTS {
        int id PK
        int child_id FK
        int parent_id FK
        int hospital_id FK
        int vaccine_id FK
        date appointment_date
        enum status
    }

    VACCINATION_RECORDS {
        int id PK
        int appointment_id FK
        int child_id FK
        int hospital_id FK
        int vaccine_id FK
        date vaccination_date
        enum status
    }

    NOTIFICATIONS {
        int id PK
        int user_id FK
        varchar title
        text message
    }
```
