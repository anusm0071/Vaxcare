# Test Cases

| Test Case ID | Module | Scenario | Preconditions | Steps | Expected Result | Actual Result | Status |
|---|---|---|---|---|---|---|---|
| TC-01 | Public website | Home page loads | App running | Open homepage | Page loads without error | [To be completed] | [To be completed] |
| TC-02 | Login | Admin login | DB imported | Enter admin credentials | Dashboard opens | [To be completed] | [To be completed] |
| TC-03 | Parent workflow | Add child | Parent logged in | Submit child form | Record is saved | [To be completed] | [To be completed] |
| TC-04 | Appointment flow | Book appointment | Parent logged in | Fill booking form | Request saved as pending | [To be completed] | [To be completed] |
| TC-05 | Admin approval | Approve request | Admin logged in | Approve pending request | Status becomes approved | [To be completed] | [To be completed] |
| TC-06 | Hospital module | Update vaccination outcome | Hospital logged in | Set status to completed | Record created in vaccination table | [To be completed] | [To be completed] |
