<?php
require_once __DIR__ . '/../includes/auth.php';
requireRole(['hospital']);
$pageTitle = 'Hospital Dashboard';
$pdo = getDb();
$user = currentUser();
$hospital = fetchHospitalByUserId((int)$user['id']);
$appointments = $pdo->prepare('SELECT a.*, c.name AS child_name, v.name AS vaccine_name FROM appointments a LEFT JOIN children c ON c.id = a.child_id LEFT JOIN vaccines v ON v.id = a.vaccine_id WHERE a.hospital_id = :hospital_id ORDER BY a.appointment_date DESC LIMIT 6');
$appointments->execute([':hospital_id' => (int)$hospital['id']]);
$appRows = $appointments->fetchAll();
$inventory = $pdo->prepare('SELECT COUNT(*) FROM hospital_vaccine_inventory WHERE hospital_id = :hospital_id');
$inventory->execute([':hospital_id' => (int)$hospital['id']]);
$inventoryCount = (int)$inventory->fetchColumn();
include __DIR__ . '/../includes/header.php';
?>
<div class="dashboard-shell">
    <?php include __DIR__ . '/../includes/hospital_sidebar.php'; ?>
    <div class="content-panel">
        <h2 class="mb-3">Hospital Overview</h2>
        <?php displayFlash(); ?>
        <div class="row g-4 mb-4">
            <div class="col-md-4">
                <div class="stat-card">
                    <div class="d-flex justify-content-between align-items-center">
                        <div>
                            <div class="text-secondary small">Assigned Appointments</div>
                            <div class="fs-3 fw-bold"><?php echo count($appRows); ?></div>
                        </div>
                        <div class="stat-icon"><i class="bi bi-calendar-check"></i></div>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="stat-card">
                    <div class="d-flex justify-content-between align-items-center">
                        <div>
                            <div class="text-secondary small">Inventory Items</div>
                            <div class="fs-3 fw-bold"><?php echo $inventoryCount; ?></div>
                        </div>
                        <div class="stat-icon"><i class="bi bi-box-seam"></i></div>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="stat-card">
                    <div class="d-flex justify-content-between align-items-center">
                        <div>
                            <div class="text-secondary small">Profile Status</div>
                            <div class="fs-6 fw-bold"><?php echo htmlspecialchars($hospital['status']); ?></div>
                        </div>
                        <div class="stat-icon"><i class="bi bi-building"></i></div>
                    </div>
                </div>
            </div>
        </div>
        <div class="card p-3">
            <h5 class="mb-3">Recent appointments</h5>
            <div class="table-responsive">
                <table class="table mb-0">
                    <thead><tr><th>Child</th><th>Vaccine</th><th>Date</th><th>Status</th><th>Action</th></tr></thead>
                    <tbody>
                        <?php if (!$appRows): ?>
                            <tr><td colspan="5" class="text-center text-secondary">No appointments assigned.</td></tr>
                        <?php else: foreach ($appRows as $row): ?>
                            <tr>
                                <td><?php echo htmlspecialchars($row['child_name']); ?></td>
                                <td><?php echo htmlspecialchars($row['vaccine_name']); ?></td>
                                <td><?php echo formatDate($row['appointment_date']); ?></td>
                                <td><span class="status-badge status-<?php echo htmlspecialchars($row['status']); ?>"><?php echo htmlspecialchars($row['status']); ?></span></td>
                                <td><a href="appointment_details.php?id=<?php echo (int)$row['id']; ?>" class="btn btn-sm btn-outline-primary">View</a></td>
                            </tr>
                        <?php endforeach; endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
<?php include __DIR__ . '/../includes/footer.php'; ?>
