<?php
require_once __DIR__ . '/../includes/auth.php';
requireRole(['hospital']);
$pageTitle = 'Hospital Reports';
$pdo = getDb();
$hospital = fetchHospitalByUserId((int)currentUser()['id']);
$reportRows = $pdo->prepare('SELECT a.appointment_date, COUNT(*) AS total FROM appointments a WHERE a.hospital_id = :hospital_id GROUP BY a.appointment_date ORDER BY a.appointment_date DESC LIMIT 10');
$reportRows->execute([':hospital_id' => (int)$hospital['id']]);
$rows = $reportRows->fetchAll();
include __DIR__ . '/../includes/header.php';
?>
<div class="dashboard-shell">
    <?php include __DIR__ . '/../includes/hospital_sidebar.php'; ?>
    <div class="content-panel">
        <h2 class="mb-3">Daily Appointment Reports</h2>
        <div class="card p-3">
            <div class="table-responsive">
                <table class="table mb-0">
                    <thead><tr><th>Date</th><th>Appointments</th></tr></thead>
                    <tbody>
                        <?php if (!$rows): ?>
                            <tr><td colspan="2" class="text-center text-secondary">No appointment data available.</td></tr>
                        <?php else: foreach ($rows as $r): ?>
                            <tr>
                                <td><?php echo formatDate($r['appointment_date']); ?></td>
                                <td><?php echo (int)$r['total']; ?></td>
                            </tr>
                        <?php endforeach; endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
<?php include __DIR__ . '/../includes/footer.php'; ?>
