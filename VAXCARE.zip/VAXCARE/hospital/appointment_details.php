<?php
require_once __DIR__ . '/../includes/auth.php';
requireRole(['hospital']);
$pageTitle = 'Appointment Details';
$pdo = getDb();
$hospital = fetchHospitalByUserId((int)currentUser()['id']);
$appointmentId = (int)($_GET['id'] ?? 0);
$stmt = $pdo->prepare('SELECT a.*, c.name AS child_name, c.date_of_birth, c.gender, p.name AS parent_name, v.name AS vaccine_name FROM appointments a LEFT JOIN children c ON c.id = a.child_id LEFT JOIN parents pr ON pr.id = a.parent_id LEFT JOIN users p ON p.id = pr.user_id LEFT JOIN vaccines v ON v.id = a.vaccine_id WHERE a.id = :id AND a.hospital_id = :hospital_id LIMIT 1');
$stmt->execute([':id' => $appointmentId, ':hospital_id' => (int)$hospital['id']]);
$appointment = $stmt->fetch();
$vaccines = $pdo->query('SELECT * FROM vaccines WHERE status = "active" ORDER BY name ASC')->fetchAll();
include __DIR__ . '/../includes/header.php';
?>
<div class="dashboard-shell">
    <?php include __DIR__ . '/../includes/hospital_sidebar.php'; ?>
    <div class="content-panel">
        <?php if (!$appointment): ?>
            <div class="alert alert-warning">Appointment not found.</div>
        <?php else: ?>
            <h2 class="mb-3">Appointment Details</h2>
            <div class="card p-4 mb-4">
                <div class="row g-3">
                    <div class="col-md-6"><strong>Child:</strong> <?php echo htmlspecialchars($appointment['child_name']); ?></div>
                    <div class="col-md-6"><strong>Parent:</strong> <?php echo htmlspecialchars($appointment['parent_name']); ?></div>
                    <div class="col-md-6"><strong>Vaccine:</strong> <?php echo htmlspecialchars($appointment['vaccine_name']); ?></div>
                    <div class="col-md-6"><strong>Date:</strong> <?php echo formatDate($appointment['appointment_date']); ?></div>
                    <div class="col-md-6"><strong>Status:</strong> <span class="status-badge status-<?php echo htmlspecialchars($appointment['status']); ?>"><?php echo htmlspecialchars($appointment['status']); ?></span></div>
                    <div class="col-md-6"><strong>Notes:</strong> <?php echo htmlspecialchars($appointment['notes'] ?? 'None'); ?></div>
                </div>
            </div>

            <div class="card p-4">
                <h5 class="mb-3">Update appointment outcome</h5>
                <form method="POST" action="../actions/vaccination_action.php">
                    <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars(generateCsrfToken(), ENT_QUOTES, 'UTF-8'); ?>">
                    <input type="hidden" name="appointment_id" value="<?php echo (int)$appointment['id']; ?>">
                    <div class="row g-3">
                        <div class="col-md-4">
                            <label class="form-label">Status</label>
                            <select class="form-select" name="status">
                                <option value="Approved">Approved</option>
                                <option value="Completed">Completed</option>
                                <option value="Cancelled">Cancelled</option>
                                <option value="Rejected">Rejected</option>
                            </select>
                        </div>
                        <div class="col-md-4">
                            <label class="form-label">Vaccine</label>
                            <select class="form-select" name="vaccine_id">
                                <?php foreach ($vaccines as $v): ?>
                                    <option value="<?php echo (int)$v['id']; ?>"><?php echo htmlspecialchars($v['name']); ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="col-md-4">
                            <label class="form-label">Staff Notes</label>
                            <input type="text" class="form-control" name="notes" value="<?php echo htmlspecialchars($appointment['notes'] ?? ''); ?>">
                        </div>
                    </div>
                    <button class="btn btn-primary mt-3" type="submit">Save Status</button>
                </form>
            </div>
        <?php endif; ?>
    </div>
</div>
<?php include __DIR__ . '/../includes/footer.php'; ?>
