<?php
require_once __DIR__ . '/../includes/auth.php';
requireRole(['hospital']);
$pageTitle = 'Vaccine Inventory';
$pdo = getDb();
$hospital = fetchHospitalByUserId((int)currentUser()['id']);
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $vaccineId = (int)($_POST['vaccine_id'] ?? 0);
    $stock = (int)($_POST['stock'] ?? 0);
    if ($vaccineId > 0) {
        $stmt = $pdo->prepare('INSERT INTO hospital_vaccine_inventory (hospital_id, vaccine_id, stock, status, created_at, updated_at) VALUES (:hospital_id, :vaccine_id, :stock, "active", NOW(), NOW()) ON DUPLICATE KEY UPDATE stock = VALUES(stock), status = "active", updated_at = NOW()');
        $stmt->execute([':hospital_id' => (int)$hospital['id'], ':vaccine_id' => $vaccineId, ':stock' => $stock]);
        flash('success', 'Inventory updated successfully.');
    }
    redirect('vaccine_inventory.php');
}
$inventory = $pdo->prepare('SELECT i.*, v.name AS vaccine_name FROM hospital_vaccine_inventory i LEFT JOIN vaccines v ON v.id = i.vaccine_id WHERE i.hospital_id = :hospital_id ORDER BY v.name ASC');
$inventory->execute([':hospital_id' => (int)$hospital['id']]);
$inventoryRows = $inventory->fetchAll();
$vaccines = $pdo->query('SELECT * FROM vaccines WHERE status = "active" ORDER BY name ASC')->fetchAll();
include __DIR__ . '/../includes/header.php';
?>
<div class="dashboard-shell">
    <?php include __DIR__ . '/../includes/hospital_sidebar.php'; ?>
    <div class="content-panel">
        <h2 class="mb-3">Vaccine Inventory</h2>
        <?php displayFlash(); ?>
        <div class="row g-4">
            <div class="col-lg-4">
                <div class="card p-4">
                    <h5>Update Inventory</h5>
                    <form method="POST">
                        <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars(generateCsrfToken(), ENT_QUOTES, 'UTF-8'); ?>">
                        <div class="mb-3">
                            <label class="form-label">Vaccine</label>
                            <select class="form-select" name="vaccine_id" required>
                                <?php foreach ($vaccines as $v): ?>
                                    <option value="<?php echo (int)$v['id']; ?>"><?php echo htmlspecialchars($v['name']); ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Stock</label>
                            <input type="number" class="form-control" name="stock" min="0" value="0" required>
                        </div>
                        <button class="btn btn-primary" type="submit">Save</button>
                    </form>
                </div>
            </div>
            <div class="col-lg-8">
                <div class="card p-3">
                    <div class="table-responsive">
                        <table class="table mb-0">
                            <thead><tr><th>Vaccine</th><th>Stock</th><th>Status</th></tr></thead>
                            <tbody>
                                <?php if (!$inventoryRows): ?>
                                    <tr><td colspan="3" class="text-center text-secondary">No vaccines in inventory.</td></tr>
                                <?php else: foreach ($inventoryRows as $row): ?>
                                    <tr>
                                        <td><?php echo htmlspecialchars($row['vaccine_name']); ?></td>
                                        <td><?php echo (int)$row['stock']; ?></td>
                                        <td><?php echo htmlspecialchars($row['status']); ?></td>
                                    </tr>
                                <?php endforeach; endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php include __DIR__ . '/../includes/footer.php'; ?>
