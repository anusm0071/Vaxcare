<?php
require_once __DIR__ . '/../includes/auth.php';
requireRole(['hospital']);
$pageTitle = 'Hospital Profile';
$pdo = getDb();
$hospital = fetchHospitalByUserId((int)currentUser()['id']);
include __DIR__ . '/../includes/header.php';
?>
<div class="dashboard-shell">
    <?php include __DIR__ . '/../includes/hospital_sidebar.php'; ?>
    <div class="content-panel">
        <h2 class="mb-3">Hospital Profile</h2>
        <?php displayFlash(); ?>
        <div class="card p-4">
            <form method="POST" action="../actions/hospital_action.php">
                <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars(generateCsrfToken(), ENT_QUOTES, 'UTF-8'); ?>">
                <div class="row g-3">
                    <div class="col-md-6">
                        <label class="form-label">Hospital Name</label>
                        <input type="text" class="form-control" name="hospital_name" value="<?php echo htmlspecialchars($hospital['hospital_name'] ?? ''); ?>" required>
                    </div>
                    <div class="col-md-6">
                        <label class="form-label">Phone</label>
                        <input type="text" class="form-control" name="phone" value="<?php echo htmlspecialchars($hospital['phone'] ?? ''); ?>" required>
                    </div>
                    <div class="col-md-6">
                        <label class="form-label">Address</label>
                        <input type="text" class="form-control" name="address" value="<?php echo htmlspecialchars($hospital['address'] ?? ''); ?>">
                    </div>
                    <div class="col-md-6">
                        <label class="form-label">City</label>
                        <input type="text" class="form-control" name="city" value="<?php echo htmlspecialchars($hospital['city'] ?? ''); ?>" required>
                    </div>
                    <div class="col-12">
                        <label class="form-label">Email</label>
                        <input type="email" class="form-control" name="email" value="<?php echo htmlspecialchars($hospital['email'] ?? ''); ?>" required>
                    </div>
                </div>
                <button class="btn btn-primary mt-3" type="submit">Update Profile</button>
            </form>
        </div>
    </div>
</div>
<?php include __DIR__ . '/../includes/footer.php'; ?>
