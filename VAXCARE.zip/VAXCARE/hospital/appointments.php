<?php
require_once __DIR__ . '/../includes/auth.php';
requireRole(['hospital']);
$pageTitle = 'Hospital Appointments';
$pdo = getDb();
$hospital = fetchHospitalByUserId((int)currentUser()['id']);
$appointments = $pdo->prepare('SELECT a.*, c.name AS child_name, p.name AS parent_name, v.name AS vaccine_name FROM appointments a LEFT JOIN children c ON c.id = a.child_id LEFT JOIN parents pr ON pr.id = a.parent_id LEFT JOIN users p ON p.id = pr.user_id LEFT JOIN vaccines v ON v.id = a.vaccine_id WHERE a.hospital_id = :hospital_id ORDER BY a.appointment_date DESC');
$appointments->execute([':hospital_id' => (int)$hospital['id']]);
$appRows = $appointments->fetchAll();
include __DIR__ . '/../includes/header.php';
?>
<div class="dashboard-shell">
    <?php include __DIR__ . '/../includes/hospital_sidebar.php'; ?>
    <div class="content-panel">
        <h2 class="mb-3">Assigned Appointments</h2>
        <?php displayFlash(); ?>
        <div class="card p-3">
            <div class="table-responsive">
                <table class="table table-hover mb-0">
                    <thead><tr><th>Child</th><th>Parent</th><th>Vaccine</th><th>Date</th><th>Status</th><th>Action</th></tr></thead>
                    <tbody>
                        <?php if (!$appRows): ?>
                            <tr><td colspan="6" class="text-center text-secondary">No appointments assigned.</td></tr>
                        <?php else: foreach ($appRows as $row): ?>
                            <tr>
                                <td><?php echo htmlspecialchars($row['child_name']); ?></td>
                                <td><?php echo htmlspecialchars($row['parent_name']); ?></td>
                                <td><?php echo htmlspecialchars($row['vaccine_name']); ?></td>
                                <td><?php echo formatDate($row['appointment_date']); ?></td>
                                <td><span class="status-badge status-<?php echo htmlspecialchars($row['status']); ?>"><?php echo htmlspecialchars($row['status']); ?></span></td>
                                <td><a href="appointment_details.php?id=<?php echo (int)$row['id']; ?>" class="btn btn-sm btn-outline-primary">Manage</a></td>
                            </tr>
                        <?php endforeach; endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
<?php include __DIR__ . '/../includes/footer.php'; ?>
