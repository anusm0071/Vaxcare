document.addEventListener('DOMContentLoaded', function () {
    const chartCanvas = document.getElementById('vaccinationChart');
    if (!chartCanvas || typeof Chart === 'undefined') {
        return;
    }

    const labels = JSON.parse(chartCanvas.dataset.labels || '[]');
    const values = JSON.parse(chartCanvas.dataset.values || '[]');

    new Chart(chartCanvas, {
        type: 'bar',
        data: {
            labels: labels,
            datasets: [{
                label: 'Vaccinations',
                data: values,
                backgroundColor: '#4f9cf9',
                borderRadius: 8,
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: { display: false }
            },
            scales: {
                y: { beginAtZero: true }
            }
        }
    });
});
