document.addEventListener('DOMContentLoaded', function () {
    const alerts = document.querySelectorAll('.alert');
    alerts.forEach(function (alert) {
        if (window.bootstrap) {
            new bootstrap.Alert(alert);
        }
    });
});
