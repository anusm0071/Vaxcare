// Client-side validation helpers for VAXCARE forms.
// Note: Server-side validation is the authoritative check; these helpers
// only improve the user experience by catching mistakes early.

(function () {
    'use strict';

    function showError(input, message) {
        input.classList.add('is-invalid');
        let feedback = input.parentElement.querySelector('.invalid-feedback');
        if (!feedback) {
            feedback = document.createElement('div');
            feedback.className = 'invalid-feedback';
            input.parentElement.appendChild(feedback);
        }
        feedback.textContent = message;
    }

    function clearError(input) {
        input.classList.remove('is-invalid');
        const feedback = input.parentElement.querySelector('.invalid-feedback');
        if (feedback) {
            feedback.remove();
        }
    }

    function validateEmailField(input) {
        const value = input.value.trim();
        const emailRe = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        if (value === '') {
            showError(input, 'Email is required.');
            return false;
        }
        if (!emailRe.test(value)) {
            showError(input, 'Please enter a valid email address.');
            return false;
        }
        clearError(input);
        return true;
    }

    function validateRequired(input) {
        if (input.value.trim() === '') {
            showError(input, 'This field is required.');
            return false;
        }
        clearError(input);
        return true;
    }

    function validatePhoneField(input) {
        const value = input.value.trim();
        const cleaned = value.replace(/[^\d+]/g, '');
        const phoneRe = /^\+?[0-9]{7,15}$/;
        if (value === '') {
            showError(input, 'Phone is required.');
            return false;
        }
        if (!phoneRe.test(cleaned)) {
            showError(input, 'Please enter a valid phone number (7-15 digits).');
            return false;
        }
        clearError(input);
        return true;
    }

    function validateDateField(input) {
        if (input.value === '') {
            showError(input, 'Please select a date.');
            return false;
        }
        clearError(input);
        return true;
    }

    function validatePassword(input) {
        if (input.value.length < 6) {
            showError(input, 'Password must be at least 6 characters.');
            return false;
        }
        clearError(input);
        return true;
    }

    function initFormValidation(formSelector, rules) {
        const form = document.querySelector(formSelector);
        if (!form) {
            return;
        }

        form.addEventListener('submit', function (event) {
            let valid = true;

            Object.keys(rules).forEach(function (fieldName) {
                const input = form.elements[fieldName];
                if (!input) {
                    return;
                }
                clearError(input);

                rules[fieldName].forEach(function (validator) {
                    if (!validator(input)) {
                        valid = false;
                    }
                });
            });

            if (!valid) {
                event.preventDefault();
                const firstInvalid = form.querySelector('.is-invalid');
                if (firstInvalid) {
                    firstInvalid.focus();
                }
            }
        });

        // Clear errors on input
        Object.keys(rules).forEach(function (fieldName) {
            const input = form.elements[fieldName];
            if (input) {
                input.addEventListener('input', function () {
                    clearError(input);
                });
            }
        });
    }

    // Auto-initialize common forms
    document.addEventListener('DOMContentLoaded', function () {
        const loginForm = document.querySelector('form[name="login"]') || document.querySelector('form[action*="login_action"]');
        if (loginForm) {
            initFormValidation('form[action*="login_action"]', {
                email: [validateEmailField],
                password: [function (input) { return input.value !== '' ? (clearError(input), true) : (showError(input, 'Password is required.'), false); }],
            });
        }

        const registerForm = document.querySelector('form[action*="register_action"]');
        if (registerForm) {
            initFormValidation('form[action*="register_action"]', {
                name: [validateRequired],
                email: [validateEmailField],
                phone: [validatePhoneField],
                password: [validatePassword],
            });
        }
    });
})();