<aside class="sidebar bg-white border-end">
    <div class="p-4 border-bottom">
        <h5 class="mb-0 text-primary"><i class="bi bi-person-heart"></i> Parent</h5>
    </div>
    <nav class="nav flex-column p-3 gap-1">
        <a class="nav-link" href="<?php echo APP_URL; ?>/parent/dashboard.php"><i class="bi bi-speedometer2"></i> Dashboard</a>
        <a class="nav-link" href="<?php echo APP_URL; ?>/parent/profile.php"><i class="bi bi-person"></i> My Profile</a>
        <a class="nav-link" href="<?php echo APP_URL; ?>/parent/children.php"><i class="bi bi-people"></i> Children</a>
        <a class="nav-link" href="<?php echo APP_URL; ?>/parent/vaccination_schedule.php"><i class="bi bi-calendar2-week"></i> Schedule</a>
        <a class="nav-link" href="<?php echo APP_URL; ?>/parent/hospitals.php"><i class="bi bi-hospital"></i> Hospitals</a>
        <a class="nav-link" href="<?php echo APP_URL; ?>/parent/book_appointment.php"><i class="bi bi-calendar-plus"></i> Book Appointment</a>
        <a class="nav-link" href="<?php echo APP_URL; ?>/parent/appointments.php"><i class="bi bi-card-checklist"></i> My Appointments</a>
        <a class="nav-link" href="<?php echo APP_URL; ?>/parent/vaccination_history.php"><i class="bi bi-clipboard2-pulse"></i> Vaccination History</a>
        <a class="nav-link" href="<?php echo APP_URL; ?>/parent/notifications.php"><i class="bi bi-bell"></i> Notifications</a>
        <a class="nav-link" href="<?php echo APP_URL; ?>/logout.php"><i class="bi bi-box-arrow-right"></i> Logout</a>
    </nav>
</aside>
