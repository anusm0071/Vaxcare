<?php

require_once __DIR__ . '/../config/database.php';

function currentUser(): ?array {
    if (empty($_SESSION['user'])) {
        return null;
    }

    return $_SESSION['user'];
}

function requireLogin(): void {
    if (!currentUser()) {
        flash('error', 'Please log in to continue.');
        redirect('../login.php');
    }
}

function requireRole(array $allowedRoles): void {
    requireLogin();

    $user = currentUser();
    if (!in_array($user['role'], $allowedRoles, true)) {
        flash('error', 'You do not have permission to access this page.');
        redirect('../index.php');
    }
}

function flash(string $type, string $message): void {
    $_SESSION['flash'] = ['type' => $type, 'message' => $message];
}

function displayFlash(): void {
    if (!empty($_SESSION['flash'])) {
        $flash = $_SESSION['flash'];
        $class = $flash['type'] === 'error' ? 'alert-danger' : ($flash['type'] === 'success' ? 'alert-success' : 'alert-info');
        echo '<div class="alert ' . htmlspecialchars($class, ENT_QUOTES, 'UTF-8') . ' alert-dismissible fade show" role="alert">';
        echo htmlspecialchars($flash['message'], ENT_QUOTES, 'UTF-8');
        echo '<button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>';
        echo '</div>';
        unset($_SESSION['flash']);
    }
}

function redirect(string $path): void {
    header('Location: ' . $path);
    exit;
}

function formatDate(?string $date, string $format = 'd M Y'): string {
    if (!$date) {
        return 'N/A';
    }

    try {
        return (new DateTime($date))->format($format);
    } catch (Exception $e) {
        return 'N/A';
    }
}

function addAuditLog(int $userId, string $action, string $entityType, ?int $entityId, string $details): void {
    $pdo = getDb();
    $stmt = $pdo->prepare('INSERT INTO audit_logs (user_id, action, entity_type, entity_id, details, created_at) VALUES (:user_id, :action, :entity_type, :entity_id, :details, NOW())');
    $stmt->execute([
        ':user_id' => $userId,
        ':action' => $action,
        ':entity_type' => $entityType,
        ':entity_id' => $entityId,
        ':details' => $details,
    ]);
}

function addNotification(int $userId, string $title, string $message, string $type = 'info'): void {
    $pdo = getDb();
    $stmt = $pdo->prepare('INSERT INTO notifications (user_id, title, message, type, is_read, created_at) VALUES (:user_id, :title, :message, :type, 0, NOW())');
    $stmt->execute([
        ':user_id' => $userId,
        ':title' => $title,
        ':message' => $message,
        ':type' => $type,
    ]);
}

function getDashboardCounts(): array {
    $pdo = getDb();
    $counts = [];

    foreach ([
        'children' => 'SELECT COUNT(*) AS total FROM children WHERE status = "active"',
        'parents' => 'SELECT COUNT(*) AS total FROM parents WHERE status = "active"',
        'hospitals' => 'SELECT COUNT(*) AS total FROM hospitals WHERE status = "active"',
        'vaccines' => 'SELECT COUNT(*) AS total FROM vaccines WHERE status = "active"',
        'pending_requests' => 'SELECT COUNT(*) AS total FROM appointments WHERE status = "Pending"',
        'upcoming' => 'SELECT COUNT(*) AS total FROM appointments WHERE status IN ("Approved", "Pending") AND appointment_date >= CURDATE()',
    ] as $key => $query) {
        $stmt = $pdo->query($query);
        $counts[$key] = (int) $stmt->fetchColumn();
    }

    return $counts;
}

function fetchUserById(int $id): ?array {
    $pdo = getDb();
    $stmt = $pdo->prepare('SELECT * FROM users WHERE id = :id LIMIT 1');
    $stmt->execute([':id' => $id]);
    return $stmt->fetch() ?: null;
}

function fetchHospitalByUserId(int $userId): ?array {
    $pdo = getDb();
    $stmt = $pdo->prepare('SELECT * FROM hospitals WHERE user_id = :user_id LIMIT 1');
    $stmt->execute([':user_id' => $userId]);
    return $stmt->fetch() ?: null;
}

function fetchParentByUserId(int $userId): ?array {
    $pdo = getDb();
    $stmt = $pdo->prepare('SELECT * FROM parents WHERE user_id = :user_id LIMIT 1');
    $stmt->execute([':user_id' => $userId]);
    return $stmt->fetch() ?: null;
}
