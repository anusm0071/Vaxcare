<aside class="sidebar bg-white border-end">
    <div class="p-4 border-bottom">
        <h5 class="mb-0 text-primary"><i class="bi bi-hospital"></i> Hospital</h5>
    </div>
    <nav class="nav flex-column p-3 gap-1">
        <a class="nav-link" href="<?php echo APP_URL; ?>/hospital/dashboard.php"><i class="bi bi-speedometer2"></i> Dashboard</a>
        <a class="nav-link" href="<?php echo APP_URL; ?>/hospital/profile.php"><i class="bi bi-building"></i> Profile</a>
        <a class="nav-link" href="<?php echo APP_URL; ?>/hospital/appointments.php"><i class="bi bi-calendar-check"></i> Appointments</a>
        <a class="nav-link" href="<?php echo APP_URL; ?>/hospital/vaccine_inventory.php"><i class="bi bi-box-seam"></i> Vaccine Inventory</a>
        <a class="nav-link" href="<?php echo APP_URL; ?>/hospital/reports.php"><i class="bi bi-bar-chart"></i> Reports</a>
        <a class="nav-link" href="<?php echo APP_URL; ?>/logout.php"><i class="bi bi-box-arrow-right"></i> Logout</a>
    </nav>
</aside>
