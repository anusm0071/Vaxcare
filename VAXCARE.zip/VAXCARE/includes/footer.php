    </main>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <script src="<?php echo APP_URL; ?>/assets/js/main.js"></script>
    <script src="<?php echo APP_URL; ?>/assets/js/validation.js"></script>
    <?php if (!empty($includeDashboardJs)) : ?>
        <script src="<?php echo APP_URL; ?>/assets/js/dashboard.js"></script>
    <?php endif; ?>
</body>
</html>
