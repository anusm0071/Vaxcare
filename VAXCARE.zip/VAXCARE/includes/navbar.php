<?php $user = currentUser(); ?>
<nav class="navbar navbar-expand-lg navbar-light bg-white shadow-sm sticky-top border-bottom">
    <div class="container">
        <a class="navbar-brand fw-bold text-primary" href="<?php echo APP_URL; ?>/index.php">
            <i class="bi bi-shield-plus"></i> VAXCARE
        </a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#mainNavbar">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="mainNavbar">
            <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                <li class="nav-item"><a class="nav-link" href="<?php echo APP_URL; ?>/index.php">Home</a></li>
                <li class="nav-item"><a class="nav-link" href="<?php echo APP_URL; ?>/about.php">About</a></li>
                <li class="nav-item"><a class="nav-link" href="<?php echo APP_URL; ?>/services.php">Services</a></li>
                <li class="nav-item"><a class="nav-link" href="<?php echo APP_URL; ?>/vaccination-guide.php">Vaccination Guide</a></li>
                <li class="nav-item"><a class="nav-link" href="<?php echo APP_URL; ?>/contact.php">Contact</a></li>
            </ul>
            <div class="d-flex align-items-center gap-2">
                <?php if ($user): ?>
                    <?php
                        $dashboardPath = '/admin/dashboard.php';
                        if ($user['role'] === 'parent') {
                            $dashboardPath = '/parent/dashboard.php';
                        } elseif ($user['role'] === 'hospital') {
                            $dashboardPath = '/hospital/dashboard.php';
                        }
                    ?>
                    <a class="btn btn-outline-primary" href="<?php echo APP_URL . $dashboardPath; ?>">Dashboard</a>
                    <a class="btn btn-primary" href="<?php echo APP_URL; ?>/logout.php">Logout</a>
                <?php else: ?>
                    <a class="btn btn-outline-primary" href="<?php echo APP_URL; ?>/login.php">Login</a>
                    <a class="btn btn-primary" href="<?php echo APP_URL; ?>/register.php">Register</a>
                <?php endif; ?>
            </div>
        </div>
    </div>
</nav>
