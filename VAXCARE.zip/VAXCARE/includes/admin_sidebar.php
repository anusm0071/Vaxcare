<aside class="sidebar bg-white border-end">
    <div class="p-4 border-bottom">
        <h5 class="mb-0 text-primary"><i class="bi bi-person-gear"></i> Admin</h5>
    </div>
    <nav class="nav flex-column p-3 gap-1">
        <a class="nav-link" href="<?php echo APP_URL; ?>/admin/dashboard.php"><i class="bi bi-speedometer2"></i> Dashboard</a>
        <a class="nav-link" href="<?php echo APP_URL; ?>/admin/children.php"><i class="bi bi-people"></i> Children</a>
        <a class="nav-link" href="<?php echo APP_URL; ?>/admin/vaccines.php"><i class="bi bi-shield-plus"></i> Vaccines</a>
        <a class="nav-link" href="<?php echo APP_URL; ?>/admin/hospitals.php"><i class="bi bi-hospital"></i> Hospitals</a>
        <a class="nav-link" href="<?php echo APP_URL; ?>/admin/appointments.php"><i class="bi bi-calendar-check"></i> Appointments</a>
        <a class="nav-link" href="<?php echo APP_URL; ?>/admin/parents.php"><i class="bi bi-person-lines-fill"></i> Parents</a>
        <a class="nav-link" href="<?php echo APP_URL; ?>/admin/users.php"><i class="bi bi-people-fill"></i> Users</a>
        <a class="nav-link" href="<?php echo APP_URL; ?>/admin/reports.php"><i class="bi bi-bar-chart"></i> Reports</a>
        <a class="nav-link" href="<?php echo APP_URL; ?>/admin/notifications.php"><i class="bi bi-bell"></i> Notifications</a>
        <a class="nav-link" href="<?php echo APP_URL; ?>/admin/settings.php"><i class="bi bi-gear"></i> Settings</a>
        <a class="nav-link" href="<?php echo APP_URL; ?>/logout.php"><i class="bi bi-box-arrow-right"></i> Logout</a>
    </nav>
</aside>
