<?php

function sanitizeString(string $value): string {
    return trim(strip_tags($value));
}

function validateEmail(string $email): bool {
    return filter_var($email, FILTER_VALIDATE_EMAIL) !== false;
}

function validatePhone(string $phone): bool {
    $cleaned = preg_replace('/[^\d+]/', '', $phone);
    return preg_match('/^\+?[0-9]{7,15}$/', $cleaned) === 1;
}

function validateDate(string $date): bool {
    $d = DateTime::createFromFormat('Y-m-d', $date);
    return $d && $d->format('Y-m-d') === $date;
}

function validatePositiveInt($value): bool {
    return filter_var($value, FILTER_VALIDATE_INT, ['options' => ['min_range' => 1]]) !== false;
}

function isNotEmpty($value): bool {
    return is_string($value) ? trim($value) !== '' : !empty($value);
}
