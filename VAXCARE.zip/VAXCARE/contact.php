<?php
require_once __DIR__ . '/includes/header.php';
$pageTitle = 'Contact';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!verifyCsrfToken($_POST['csrf_token'] ?? '')) {
        flash('error', 'Security token expired.');
    } else {
        $name = sanitizeString($_POST['name'] ?? '');
        $email = sanitizeString($_POST['email'] ?? '');
        $subject = sanitizeString($_POST['subject'] ?? '');
        $message = sanitizeString($_POST['message'] ?? '');

        if ($name === '' || !validateEmail($email) || $subject === '' || $message === '') {
            flash('error', 'Please complete the contact form correctly.');
        } else {
            try {
                $pdo = getDb();
                $stmt = $pdo->prepare('INSERT INTO contact_messages (name, email, subject, message, created_at) VALUES (:name, :email, :subject, :message, NOW())');
                $stmt->execute([
                    ':name' => $name,
                    ':email' => $email,
                    ':subject' => $subject,
                    ':message' => $message,
                ]);
                flash('success', 'Your message has been sent successfully.');
            } catch (Throwable $e) {
                error_log($e->getMessage());
                flash('error', 'Unable to send your message at the moment.');
            }
        }
    }
}
?>
<section class="py-5">
    <div class="container">
        <div class="row g-4">
            <div class="col-lg-5">
                <h1 class="section-title">Contact Us</h1>
                <p class="text-secondary">We are happy to help with appointment questions, account support and technical assistance.</p>
                <ul class="list-unstyled">
                    <li class="mb-3"><i class="bi bi-geo-alt-fill text-primary me-2"></i> 25 Wellness Avenue, Lahore</li>
                    <li class="mb-3"><i class="bi bi-envelope text-primary me-2"></i> support@vaxcare.example</li>
                    <li class="mb-3"><i class="bi bi-telephone text-primary me-2"></i> +92 300 1234567</li>
                </ul>
            </div>
            <div class="col-lg-7">
                <div class="card p-4">
                    <?php displayFlash(); ?>
                    <form method="POST" action="contact.php">
                        <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars(generateCsrfToken(), ENT_QUOTES, 'UTF-8'); ?>">
                        <div class="row g-3">
                            <div class="col-md-6">
                                <label class="form-label">Name</label>
                                <input type="text" class="form-control" name="name" required>
                            </div>
                            <div class="col-md-6">
                                <label class="form-label">Email</label>
                                <input type="email" class="form-control" name="email" required>
                            </div>
                            <div class="col-12">
                                <label class="form-label">Subject</label>
                                <input type="text" class="form-control" name="subject" required>
                            </div>
                            <div class="col-12">
                                <label class="form-label">Message</label>
                                <textarea class="form-control" name="message" rows="5" required></textarea>
                            </div>
                            <div class="col-12 text-end">
                                <button class="btn btn-primary" type="submit">Send Message</button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</section>
<?php include __DIR__ . '/includes/footer.php'; ?>
