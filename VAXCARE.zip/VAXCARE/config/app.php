<?php

define('BASE_PATH', __DIR__ . '/..');

function env(string $key, $default = null) {
    $value = $_ENV[$key] ?? $_SERVER[$key] ?? getenv($key);

    if ($value === false || $value === null || $value === '') {
        return $default;
    }

    return $value;
}

function loadEnvFile(string $path): void {
    if (!is_file($path)) {
        return;
    }

    $lines = file($path, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);

    foreach ($lines as $line) {
        if (str_starts_with(trim($line), '#')) {
            continue;
        }

        [$name, $value] = array_pad(explode('=', $line, 2), 2, null);
        $name = trim($name);
        $value = trim($value);

        if ($name === '') {
            continue;
        }

        $_ENV[$name] = $value;
        $_SERVER[$name] = $value;
        putenv("{$name}={$value}");
    }
}

loadEnvFile(BASE_PATH . '/.env');

define('APP_NAME', 'VAXCARE');
define('APP_URL', env('APP_URL', 'http://localhost/VAXCARE'));
define('APP_ENV', env('APP_ENV', 'local'));
