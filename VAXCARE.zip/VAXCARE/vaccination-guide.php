<?php
require_once __DIR__ . '/includes/header.php';
$pageTitle = 'Vaccination Guide';
?>
<section class="py-5">
    <div class="container">
        <h1 class="section-title">Vaccination Guide</h1>
        <div class="card p-4">
            <p class="text-secondary">This application supports vaccine record management and appointment tracking. It does not replace formal medical advice. Families should consult a licensed healthcare professional regarding local vaccination schedules and medical decisions.</p>
            <ul>
                <li>Keep child records updated and complete.</li>
                <li>Confirm the recommended schedule with a doctor or clinic.</li>
                <li>Record all appointments and completed vaccination details.</li>
            </ul>
        </div>
    </div>
</section>
<?php include __DIR__ . '/includes/footer.php'; ?>
